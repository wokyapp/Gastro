import { mockProducts, mockSales } from './mockData';

// Simular escaneo de producto
export const mockScanProduct = async (barcode: string) => {
  // Simular tiempo de procesamiento
  await new Promise(resolve => setTimeout(resolve, 500));
  // Buscar producto por código de barras
  const product = mockProducts.find(p => p.barcode === barcode);
  return product || null;
};

// Obtener producto por ID
export const getProductById = async (id: string) => {
  // Simular tiempo de procesamiento
  await new Promise(resolve => setTimeout(resolve, 300));
  // Buscar producto por ID
  const product = mockProducts.find(p => p.id === id);
  return product || null;
};

// Simular búsqueda de venta por ID
export const getSaleById = async (id: string) => {
  // Simular tiempo de procesamiento
  await new Promise(resolve => setTimeout(resolve, 800));
  // Buscar venta por ID
  const sale = mockSales.find(s => s.id === id);
  return sale || null;
};

// Simular generación de ticket
export const generateTicket = async (saleId?: string, method?: string) => {
  // Simular tiempo de procesamiento
  await new Promise(resolve => setTimeout(resolve, 1500));
  return {
    success: true,
    method,
    url: `https://example.com/ticket/${saleId}`
  };
};

// Simular procesamiento de venta
export const processSale = async (saleData: any) => {
  // Simular tiempo de procesamiento
  await new Promise(resolve => setTimeout(resolve, 1500));
  // Generar ID único para la venta
  const saleId = `SALE-${Date.now().toString().substring(7)}`;
  return {
    success: true,
    saleId,
    message: 'Venta procesada correctamente'
  };
};