import React from 'react';
import { UtensilsIcon, ShoppingBagIcon } from 'lucide-react';
interface OrderTypeSelectorProps {
  selectedType: 'mesa' | 'llevar';
  onTypeChange: (type: 'mesa' | 'llevar') => void;
}
const OrderTypeSelector: React.FC<OrderTypeSelectorProps> = ({
  selectedType,
  onTypeChange
}) => {
  return <div className="flex space-x-2 mb-2">
      <button onClick={() => onTypeChange('mesa')} className={`flex-1 py-2 px-3 rounded-lg flex items-center justify-center text-sm font-medium ${selectedType === 'mesa' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
        <UtensilsIcon size={16} className="mr-2" />
        En Mesa
      </button>
      <button onClick={() => onTypeChange('llevar')} className={`flex-1 py-2 px-3 rounded-lg flex items-center justify-center text-sm font-medium ${selectedType === 'llevar' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
        <ShoppingBagIcon size={16} className="mr-2" />
        Para Llevar
      </button>
    </div>;
};
export default OrderTypeSelector;