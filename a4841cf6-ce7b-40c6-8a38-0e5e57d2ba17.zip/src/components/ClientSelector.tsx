import React, { useState } from 'react';
import { SearchIcon, PlusIcon, UserIcon, XIcon } from 'lucide-react';
// Mock data for clients
const mockClients = [{
  id: 1,
  name: 'Juan Pérez',
  document: '1234567890',
  documentType: 'CC',
  address: 'Calle 123 #45-67',
  phone: '3001234567'
}, {
  id: 2,
  name: 'María López',
  document: '0987654321',
  documentType: 'CC',
  address: 'Carrera 45 #12-34',
  phone: '3109876543'
}, {
  id: 3,
  name: 'Carlos Rodríguez',
  document: '5678901234',
  documentType: 'NIT',
  address: 'Avenida 67 #89-12',
  phone: '3205678901'
}, {
  id: 4,
  name: 'Ana Martínez',
  document: '4321098765',
  documentType: 'CE',
  address: 'Diagonal 23 #45-67',
  phone: '3154321098'
}, {
  id: 5,
  name: 'Pedro González',
  document: '9876543210',
  documentType: 'CC',
  address: 'Calle 89 #12-34',
  phone: '3009876543'
}];
const ClientSelector = ({
  onSelectClient
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddClientForm, setShowAddClientForm] = useState(false);
  const [newClient, setNewClient] = useState({
    name: '',
    document: '',
    documentType: 'CC',
    address: '',
    phone: ''
  });
  // Filter clients based on search query
  const filteredClients = mockClients.filter(client => client.name.toLowerCase().includes(searchQuery.toLowerCase()) || client.document.includes(searchQuery));
  // Handle new client form submission
  const handleAddClient = e => {
    e.preventDefault();
    onSelectClient({
      id: Math.floor(Math.random() * 1000),
      ...newClient
    });
    setShowAddClientForm(false);
  };
  return <div>
      {!showAddClientForm ? <>
          <div className="flex mb-4">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <SearchIcon size={16} className="text-gray-400" />
              </div>
              <input type="text" className="pl-10 block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Buscar por nombre o documento" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
            </div>
            <button className="ml-2 bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 flex items-center" onClick={() => setShowAddClientForm(true)}>
              <PlusIcon size={16} className="mr-1" />
              <span>Nuevo</span>
            </button>
          </div>
          <div className="max-h-60 overflow-y-auto">
            {filteredClients.length > 0 ? <div className="divide-y divide-gray-100">
                {filteredClients.map(client => <div key={client.id} className="p-3 hover:bg-gray-50 cursor-pointer" onClick={() => onSelectClient(client)}>
                    <div className="flex items-start">
                      <div className="p-2 bg-blue-100 text-blue-600 rounded-full mr-3">
                        <UserIcon size={16} />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">
                          {client.name}
                        </p>
                        <p className="text-sm text-gray-600">
                          {client.documentType}: {client.document}
                        </p>
                        {client.address && <p className="text-xs text-gray-500 mt-1">
                            {client.address}
                          </p>}
                      </div>
                    </div>
                  </div>)}
              </div> : <div className="text-center py-4 text-gray-500">
                No se encontraron clientes
              </div>}
          </div>
        </> : <form onSubmit={handleAddClient}>
          <div className="mb-3 flex justify-between items-center">
            <h3 className="text-sm font-medium text-gray-700">Nuevo Cliente</h3>
            <button type="button" className="text-gray-400 hover:text-gray-600" onClick={() => setShowAddClientForm(false)}>
              <XIcon size={16} />
            </button>
          </div>
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">
                Nombre completo
              </label>
              <input type="text" className="block w-full rounded-lg border border-gray-300 py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={newClient.name} onChange={e => setNewClient({
            ...newClient,
            name: e.target.value
          })} required />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Tipo de documento
                </label>
                <select className="block w-full rounded-lg border border-gray-300 py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={newClient.documentType} onChange={e => setNewClient({
              ...newClient,
              documentType: e.target.value
            })} required>
                  <option value="CC">CC</option>
                  <option value="NIT">NIT</option>
                  <option value="CE">CE</option>
                  <option value="PASAPORTE">Pasaporte</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Número de documento
                </label>
                <input type="text" className="block w-full rounded-lg border border-gray-300 py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={newClient.document} onChange={e => setNewClient({
              ...newClient,
              document: e.target.value
            })} required />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">
                Dirección
              </label>
              <input type="text" className="block w-full rounded-lg border border-gray-300 py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={newClient.address} onChange={e => setNewClient({
            ...newClient,
            address: e.target.value
          })} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">
                Teléfono
              </label>
              <input type="tel" className="block w-full rounded-lg border border-gray-300 py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={newClient.phone} onChange={e => setNewClient({
            ...newClient,
            phone: e.target.value
          })} />
            </div>
            <div className="pt-2">
              <button type="submit" className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 text-sm font-medium">
                Guardar Cliente
              </button>
            </div>
          </div>
        </form>}
    </div>;
};
export default ClientSelector;