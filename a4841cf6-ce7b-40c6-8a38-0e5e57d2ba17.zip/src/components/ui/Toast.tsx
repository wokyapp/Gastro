import React, { useEffect, useState } from 'react';
import { CheckCircleIcon, AlertCircleIcon, XCircleIcon, InfoIcon, XIcon } from 'lucide-react';
export type ToastType = 'success' | 'error' | 'warning' | 'info';
interface ToastProps {
  type: ToastType;
  message: string;
  duration?: number;
  onClose: () => void;
}
const Toast: React.FC<ToastProps> = ({
  type,
  message,
  duration = 3000,
  onClose
}) => {
  const [isVisible, setIsVisible] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onClose, 300); // Allow for exit animation
    }, duration);
    return () => clearTimeout(timer);
  }, [duration, onClose]);
  const icons = {
    success: <CheckCircleIcon className="text-green-500" size={20} />,
    error: <XCircleIcon className="text-red-500" size={20} />,
    warning: <AlertCircleIcon className="text-amber-500" size={20} />,
    info: <InfoIcon className="text-blue-500" size={20} />
  };
  const bgColors = {
    success: 'bg-green-50 border-green-200',
    error: 'bg-red-50 border-red-200',
    warning: 'bg-amber-50 border-amber-200',
    info: 'bg-blue-50 border-blue-200'
  };
  const progressColors = {
    success: 'bg-green-500',
    error: 'bg-red-500',
    warning: 'bg-amber-500',
    info: 'bg-blue-500'
  };
  return <div className={`fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50 w-[calc(100%-2rem)] max-w-sm 
        ${bgColors[type]} border rounded-lg shadow-lg transition-all duration-300 
        ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}>
      <div className="flex items-start p-3">
        <div className="flex-shrink-0">{icons[type]}</div>
        <div className="ml-3 w-0 flex-1 pt-0.5">
          <p className="text-sm text-gray-800 font-medium">{message}</p>
        </div>
        <div className="ml-4 flex-shrink-0 flex">
          <button className="inline-flex text-gray-400 hover:text-gray-500 focus:outline-none p-1 rounded-full hover:bg-gray-100" onClick={() => {
          setIsVisible(false);
          setTimeout(onClose, 300);
        }}>
            <XIcon size={16} />
          </button>
        </div>
      </div>
      <div className="h-1 w-full bg-gray-200 rounded-b-lg overflow-hidden">
        <div className={`h-full ${progressColors[type]} animate-shrink`} style={{
        animationDuration: `${duration}ms`
      }}></div>
      </div>
    </div>;
};
export default Toast;