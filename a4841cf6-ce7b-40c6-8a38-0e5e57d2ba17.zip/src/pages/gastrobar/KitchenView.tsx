import React, { useEffect, useState } from 'react';
import { ClockIcon, ChefHatIcon, CheckCircleIcon, BellIcon, ArrowRightIcon, PrinterIcon, InfoIcon, SearchIcon } from 'lucide-react';
import { useToast } from '../../contexts/ToastContext';
// Tipos
interface OrderItem {
  id: string;
  name: string;
  quantity: number;
  notes?: string;
  category: string;
  preparationTime: number; // en minutos
}
interface KitchenOrder {
  id: string;
  tableNumber: string;
  items: OrderItem[];
  status: 'new' | 'preparing' | 'ready';
  waiter: string;
  createdAt: string;
  priority: 'normal' | 'high';
  notes?: string;
  timeElapsed: number; // en minutos
}
// Datos de ejemplo
const mockKitchenOrders: KitchenOrder[] = [{
  id: 'ORD-1001',
  tableNumber: '5',
  items: [{
    id: 'ITEM-1',
    name: 'Hamburguesa Clásica',
    quantity: 2,
    category: 'Hamburguesas',
    preparationTime: 15,
    notes: 'Una sin cebolla'
  }, {
    id: 'ITEM-2',
    name: 'Papas Fritas',
    quantity: 1,
    category: 'Acompañamientos',
    preparationTime: 8
  }],
  status: 'new',
  waiter: 'Carlos Rodríguez',
  createdAt: new Date(Date.now() - 5 * 60000).toISOString(),
  priority: 'normal',
  timeElapsed: 5
}, {
  id: 'ORD-1002',
  tableNumber: '8',
  items: [{
    id: 'ITEM-3',
    name: 'Ensalada César',
    quantity: 1,
    category: 'Ensaladas',
    preparationTime: 10
  }, {
    id: 'ITEM-4',
    name: 'Lomo de Res',
    quantity: 1,
    category: 'Carnes',
    preparationTime: 20,
    notes: 'Término medio'
  }],
  status: 'preparing',
  waiter: 'Ana Martínez',
  createdAt: new Date(Date.now() - 15 * 60000).toISOString(),
  priority: 'high',
  timeElapsed: 15
}, {
  id: 'ORD-1003',
  tableNumber: '3',
  items: [{
    id: 'ITEM-5',
    name: 'Pizza Margherita',
    quantity: 1,
    category: 'Pizzas',
    preparationTime: 18
  }],
  status: 'ready',
  waiter: 'Pedro Gómez',
  createdAt: new Date(Date.now() - 25 * 60000).toISOString(),
  timeElapsed: 25
}, {
  id: 'ORD-1004',
  tableNumber: '10',
  items: [{
    id: 'ITEM-6',
    name: 'Nachos con Queso',
    quantity: 2,
    category: 'Entradas',
    preparationTime: 12
  }, {
    id: 'ITEM-7',
    name: 'Alitas BBQ',
    quantity: 1,
    category: 'Entradas',
    preparationTime: 15,
    notes: 'Extra picantes'
  }],
  status: 'new',
  waiter: 'Laura Sánchez',
  createdAt: new Date(Date.now() - 2 * 60000).toISOString(),
  priority: 'normal',
  timeElapsed: 2
}, {
  id: 'ORD-1005',
  tableNumber: '7',
  items: [{
    id: 'ITEM-8',
    name: 'Pasta Alfredo',
    quantity: 1,
    category: 'Pastas',
    preparationTime: 15
  }, {
    id: 'ITEM-9',
    name: 'Pan de Ajo',
    quantity: 1,
    category: 'Entradas',
    preparationTime: 8
  }],
  status: 'preparing',
  waiter: 'Carlos Rodríguez',
  createdAt: new Date(Date.now() - 10 * 60000).toISOString(),
  priority: 'normal',
  timeElapsed: 10
}, {
  id: 'ORD-1006',
  tableNumber: '2',
  items: [{
    id: 'ITEM-10',
    name: 'Sopa de Tomate',
    quantity: 2,
    category: 'Sopas',
    preparationTime: 10
  }],
  status: 'ready',
  waiter: 'Ana Martínez',
  createdAt: new Date(Date.now() - 20 * 60000).toISOString(),
  timeElapsed: 20
}];
const KitchenView: React.FC = () => {
  const {
    showToast
  } = useToast();
  const [orders, setOrders] = useState<KitchenOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<KitchenOrder | null>(null);
  const [showOrderDetails, setShowOrderDetails] = useState(false);
  useEffect(() => {
    // Simular carga de datos
    const loadData = async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setOrders(mockKitchenOrders);
      setLoading(false);
    };
    loadData();
    // Actualizar el tiempo transcurrido cada minuto
    const timer = setInterval(() => {
      setOrders(prevOrders => prevOrders.map(order => ({
        ...order,
        timeElapsed: Math.floor((Date.now() - new Date(order.createdAt).getTime()) / 60000)
      })));
    }, 60000);
    return () => clearInterval(timer);
  }, []);
  // Filtrar órdenes según el término de búsqueda
  const filteredOrders = orders.filter(order => order.id.toLowerCase().includes(searchTerm.toLowerCase()) || order.tableNumber.includes(searchTerm) || order.items.some(item => item.name.toLowerCase().includes(searchTerm.toLowerCase())));
  // Obtener órdenes por estado
  const getOrdersByStatus = (status: 'new' | 'preparing' | 'ready') => {
    return filteredOrders.filter(order => order.status === status);
  };
  // Cambiar estado de la orden
  const moveOrder = (orderId: string, newStatus: 'new' | 'preparing' | 'ready') => {
    setOrders(orders.map(order => order.id === orderId ? {
      ...order,
      status: newStatus
    } : order));
    showToast('success', `Orden ${orderId} movida a ${getStatusLabel(newStatus)}`);
  };
  // Cambiar prioridad de la orden
  const togglePriority = (orderId: string) => {
    setOrders(orders.map(order => order.id === orderId ? {
      ...order,
      priority: order.priority === 'normal' ? 'high' : 'normal'
    } : order));
    const order = orders.find(o => o.id === orderId);
    if (order) {
      showToast('info', `Prioridad de orden ${orderId} cambiada a ${order.priority === 'normal' ? 'alta' : 'normal'}`);
    }
  };
  // Imprimir orden
  const printOrder = (orderId: string) => {
    showToast('info', `Imprimiendo orden ${orderId}...`);
    // Lógica de impresión aquí
  };
  // Ver detalles de orden
  const viewOrderDetails = (order: KitchenOrder) => {
    setSelectedOrder(order);
    setShowOrderDetails(true);
  };
  // Obtener etiqueta para el estado
  const getStatusLabel = (status: 'new' | 'preparing' | 'ready'): string => {
    switch (status) {
      case 'new':
        return 'Orden';
      case 'preparing':
        return 'Preparación';
      case 'ready':
        return 'Lista';
      default:
        return status;
    }
  };
  // Renderizar tarjeta de orden
  const renderOrderCard = (order: KitchenOrder) => {
    const isOverdue = order.status === 'new' && order.timeElapsed > 5 ? true : order.status === 'preparing' && order.timeElapsed > order.items.reduce((max, item) => Math.max(max, item.preparationTime), 0) ? true : false;
    return <div key={order.id} className={`border rounded-lg shadow-sm mb-3 overflow-hidden ${order.priority === 'high' ? 'border-red-400 bg-red-50' : isOverdue ? 'border-amber-400 bg-amber-50' : 'border-gray-200 bg-white'}`}>
        <div className="flex justify-between items-center p-3 bg-gray-50 border-b border-gray-200">
          <div className="flex items-center">
            <span className="font-medium text-gray-800">{order.id}</span>
            <span className="mx-2 text-gray-400">•</span>
            <span className="text-gray-600">Mesa {order.tableNumber}</span>
          </div>
          <div className="flex space-x-1">
            <button onClick={() => togglePriority(order.id)} className={`p-1 rounded-full ${order.priority === 'high' ? 'text-red-600 bg-red-100' : 'text-gray-400 hover:bg-gray-100'}`} title="Cambiar prioridad">
              <BellIcon size={16} />
            </button>
            <button onClick={() => printOrder(order.id)} className="p-1 rounded-full text-gray-400 hover:bg-gray-100" title="Imprimir orden">
              <PrinterIcon size={16} />
            </button>
            <button onClick={() => viewOrderDetails(order)} className="p-1 rounded-full text-gray-400 hover:bg-gray-100" title="Ver detalles">
              <InfoIcon size={16} />
            </button>
          </div>
        </div>
        <div className="p-3">
          <div className="space-y-2 mb-3">
            {order.items.map(item => <div key={item.id} className="flex justify-between">
                <div>
                  <span className="font-medium text-gray-800">
                    {item.quantity}x
                  </span>{' '}
                  <span>{item.name}</span>
                  {item.notes && <p className="text-xs text-gray-500">{item.notes}</p>}
                </div>
                <span className="text-xs bg-blue-100 text-blue-800 py-0.5 px-2 rounded-full">
                  {item.category}
                </span>
              </div>)}
          </div>
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center text-gray-500">
              <ClockIcon size={14} className="mr-1" />
              <span>
                {order.timeElapsed}{' '}
                {order.timeElapsed === 1 ? 'minuto' : 'minutos'}
              </span>
            </div>
            <div className="flex space-x-1">
              {order.status === 'new' && <button onClick={() => moveOrder(order.id, 'preparing')} className="bg-blue-600 hover:bg-blue-700 text-white px-2 py-1 rounded text-xs flex items-center">
                  <ChefHatIcon size={12} className="mr-1" />
                  Preparar
                </button>}
              {order.status === 'preparing' && <button onClick={() => moveOrder(order.id, 'ready')} className="bg-green-600 hover:bg-green-700 text-white px-2 py-1 rounded text-xs flex items-center">
                  <CheckCircleIcon size={12} className="mr-1" />
                  Lista
                </button>}
              {order.status === 'ready' && <button onClick={() => {
              // Eliminar la orden cuando se entrega
              setOrders(orders.filter(o => o.id !== order.id));
              showToast('success', `Orden ${order.id} entregada`);
            }} className="bg-purple-600 hover:bg-purple-700 text-white px-2 py-1 rounded text-xs flex items-center">
                  Entregar
                </button>}
            </div>
          </div>
        </div>
      </div>;
  };
  // Modal de detalles de orden
  const renderOrderDetailsModal = () => {
    if (!selectedOrder) return null;
    return <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-lg shadow-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
          <div className="p-4 border-b border-gray-200">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium text-gray-900">
                Detalles de Orden
              </h3>
              <button onClick={() => setShowOrderDetails(false)} className="text-gray-400 hover:text-gray-500">
                <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>
          <div className="p-4 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Orden ID</p>
                <p className="font-medium">{selectedOrder.id}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Mesa</p>
                <p className="font-medium">{selectedOrder.tableNumber}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Mesero</p>
                <p className="font-medium">{selectedOrder.waiter}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Hora</p>
                <p className="font-medium">
                  {new Date(selectedOrder.createdAt).toLocaleTimeString('es-CO', {
                  hour: '2-digit',
                  minute: '2-digit'
                })}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Estado</p>
                <p className="font-medium">
                  {getStatusLabel(selectedOrder.status)}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Prioridad</p>
                <p className={`font-medium ${selectedOrder.priority === 'high' ? 'text-red-600' : 'text-gray-900'}`}>
                  {selectedOrder.priority === 'high' ? 'Alta' : 'Normal'}
                </p>
              </div>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-2">Ítems</p>
              <div className="border border-gray-200 rounded-lg divide-y divide-gray-200">
                {selectedOrder.items.map(item => <div key={item.id} className="p-3">
                    <div className="flex justify-between mb-1">
                      <div className="font-medium">
                        {item.quantity}x {item.name}
                      </div>
                      <div className="text-xs bg-blue-100 text-blue-800 py-0.5 px-2 rounded-full">
                        {item.category}
                      </div>
                    </div>
                    {item.notes && <p className="text-sm text-gray-500">{item.notes}</p>}
                    <p className="text-xs text-gray-400 mt-1">
                      Tiempo estimado: {item.preparationTime} minutos
                    </p>
                  </div>)}
              </div>
            </div>
            {selectedOrder.notes && <div>
                <p className="text-sm text-gray-500 mb-1">Notas generales</p>
                <p className="text-sm border border-gray-200 rounded-lg p-3">
                  {selectedOrder.notes}
                </p>
              </div>}
          </div>
          <div className="p-4 border-t border-gray-200 flex justify-end space-x-2">
            <button onClick={() => setShowOrderDetails(false)} className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
              Cerrar
            </button>
            <button onClick={() => {
            printOrder(selectedOrder.id);
            setShowOrderDetails(false);
          }} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
              <PrinterIcon size={16} className="mr-1" />
              Imprimir
            </button>
          </div>
        </div>
      </div>;
  };
  if (loading) {
    return <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>;
  }
  return <div className="h-full">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Cocina</h1>
          <p className="text-gray-600 text-sm">
            Gestión de órdenes en preparación
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon size={16} className="text-gray-400" />
            </div>
            <input type="text" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="pl-10 block rounded-lg border border-gray-300 py-1.5 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Buscar orden..." />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Columna 1: Órdenes nuevas */}
        <div className="bg-white rounded-xl shadow-sm p-4 h-[calc(100vh-160px)] overflow-y-auto">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-gray-800 flex items-center">
              <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
              Orden
            </h2>
            <span className="text-sm bg-blue-100 text-blue-800 py-0.5 px-2 rounded-full">
              {getOrdersByStatus('new').length}
            </span>
          </div>
          {getOrdersByStatus('new').length > 0 ? getOrdersByStatus('new').map(order => renderOrderCard(order)) : <div className="flex flex-col items-center justify-center h-40 text-gray-400">
              <svg className="w-10 h-10 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <p>No hay órdenes nuevas</p>
            </div>}
        </div>

        {/* Columna 2: Órdenes en preparación */}
        <div className="bg-white rounded-xl shadow-sm p-4 h-[calc(100vh-160px)] overflow-y-auto">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-gray-800 flex items-center">
              <span className="w-2 h-2 bg-amber-500 rounded-full mr-2"></span>
              Preparación
            </h2>
            <span className="text-sm bg-amber-100 text-amber-800 py-0.5 px-2 rounded-full">
              {getOrdersByStatus('preparing').length}
            </span>
          </div>
          {getOrdersByStatus('preparing').length > 0 ? getOrdersByStatus('preparing').map(order => renderOrderCard(order)) : <div className="flex flex-col items-center justify-center h-40 text-gray-400">
              <ChefHatIcon size={40} className="mb-2" />
              <p>No hay órdenes en preparación</p>
            </div>}
        </div>

        {/* Columna 3: Órdenes listas */}
        <div className="bg-white rounded-xl shadow-sm p-4 h-[calc(100vh-160px)] overflow-y-auto">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-gray-800 flex items-center">
              <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
              Lista
            </h2>
            <span className="text-sm bg-green-100 text-green-800 py-0.5 px-2 rounded-full">
              {getOrdersByStatus('ready').length}
            </span>
          </div>
          {getOrdersByStatus('ready').length > 0 ? getOrdersByStatus('ready').map(order => renderOrderCard(order)) : <div className="flex flex-col items-center justify-center h-40 text-gray-400">
              <CheckCircleIcon size={40} className="mb-2" />
              <p>No hay órdenes listas</p>
            </div>}
        </div>
      </div>

      {showOrderDetails && renderOrderDetailsModal()}
    </div>;
};
export default KitchenView;