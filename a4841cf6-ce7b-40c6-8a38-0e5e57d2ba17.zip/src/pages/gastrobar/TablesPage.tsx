import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../contexts/ToastContext';
import { useAuth } from '../../contexts/AuthContext';
import { ClockIcon, UserIcon, UtensilsIcon, UserCircleIcon, PlusIcon } from 'lucide-react';
// Tipo para meseros
interface Waiter {
  id: number;
  name: string;
  active: boolean;
}
const TablesPage = () => {
  const {
    showToast
  } = useToast();
  const navigate = useNavigate();
  const {
    user
  } = useAuth();
  const [tables, setTables] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedTable, setSelectedTable] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [currentTime, setCurrentTime] = useState(new Date());
  // Update the current time every minute to keep elapsed times accurate
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000); // Update every minute
    return () => clearInterval(timer);
  }, []);
  // Function to calculate and format elapsed time
  const getElapsedTime = orderTime => {
    if (!orderTime) return null;
    const orderDate = new Date(orderTime);
    const diffMs = currentTime - orderDate;
    // Convert to minutes and hours
    const diffMinutes = Math.floor(diffMs / 60000);
    const hours = Math.floor(diffMinutes / 60);
    const minutes = diffMinutes % 60;
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else {
      return `${minutes}m`;
    }
  };
  // Lista de meseros (simulada)
  const [waiters, setWaiters] = useState([{
    id: 1,
    name: 'Carlos Rodríguez',
    active: true
  }, {
    id: 2,
    name: 'María López',
    active: true
  }, {
    id: 3,
    name: 'Juan Pérez',
    active: true
  }, {
    id: 4,
    name: 'Ana García',
    active: false
  }]);
  useEffect(() => {
    const loadTables = async () => {
      // Simulación de carga de datos
      await new Promise(resolve => setTimeout(resolve, 800));
      // Datos de ejemplo
      const mockTables = [{
        id: 1,
        name: 'Mesa 1',
        seats: 4,
        status: 'occupied',
        waiter: {
          id: 1,
          name: 'Carlos Rodríguez'
        },
        order: {
          id: 'ORD-001',
          items: 3,
          total: 45600,
          time: '00:35',
          customerName: 'Juan Gómez',
          details: [{
            id: 1,
            name: 'Hamburguesa Clásica',
            price: 18000,
            quantity: 2
          }, {
            id: 3,
            name: 'Cerveza Artesanal',
            price: 12000,
            quantity: 1
          }]
        },
        reservation: null
      }, {
        id: 2,
        name: 'Mesa 2',
        seats: 2,
        status: 'available',
        waiter: null,
        order: null,
        reservation: null
      }, {
        id: 3,
        name: 'Mesa 3',
        seats: 6,
        status: 'occupied',
        waiter: {
          id: 2,
          name: 'María López'
        },
        order: {
          id: 'ORD-002',
          items: 5,
          total: 87200,
          time: '00:12',
          customerName: 'Familia Torres',
          details: [{
            id: 8,
            name: 'Pizza Margarita',
            price: 22000,
            quantity: 2
          }, {
            id: 5,
            name: 'Agua Mineral',
            price: 5000,
            quantity: 1
          }, {
            id: 11,
            name: 'Nachos con Guacamole',
            price: 18000,
            quantity: 2
          }]
        },
        reservation: null
      }, {
        id: 4,
        name: 'Mesa 4',
        seats: 4,
        status: 'reserved',
        waiter: {
          id: 3,
          name: 'Juan Pérez'
        },
        order: null,
        reservation: {
          name: 'Familia Rodríguez',
          time: '19:30',
          people: 4
        }
      }, {
        id: 5,
        name: 'Mesa 5',
        seats: 2,
        status: 'available',
        waiter: null,
        order: null,
        reservation: null
      }, {
        id: 6,
        name: 'Mesa 6',
        seats: 8,
        status: 'occupied',
        waiter: {
          id: 2,
          name: 'María López'
        },
        order: {
          id: 'ORD-003',
          items: 12,
          total: 154000,
          time: '01:05',
          customerName: 'Grupo Ejecutivo',
          details: [{
            id: 12,
            name: 'Combo Hamburguesa',
            price: 32000,
            quantity: 3
          }, {
            id: 10,
            name: 'Vino Tinto',
            price: 15000,
            quantity: 3
          }, {
            id: 7,
            name: 'Postre del Día',
            price: 9000,
            quantity: 3
          }]
        },
        reservation: null
      }, {
        id: 7,
        name: 'Barra 1',
        seats: 1,
        status: 'available',
        waiter: null,
        order: null,
        reservation: null
      }, {
        id: 8,
        name: 'Barra 2',
        seats: 1,
        status: 'occupied',
        waiter: {
          id: 1,
          name: 'Carlos Rodríguez'
        },
        order: {
          id: 'ORD-004',
          items: 2,
          total: 24000,
          time: '00:08',
          customerName: 'Pedro Martínez',
          details: [{
            id: 3,
            name: 'Cerveza Artesanal',
            price: 12000,
            quantity: 2
          }]
        },
        reservation: null
      }, {
        id: 9,
        name: 'Terraza 1',
        seats: 4,
        status: 'reserved',
        waiter: {
          id: 3,
          name: 'Juan Pérez'
        },
        order: null,
        reservation: {
          name: 'Carlos Méndez',
          time: '20:15',
          people: 3
        }
      }, {
        id: 10,
        name: 'Terraza 2',
        seats: 4,
        status: 'available',
        waiter: null,
        order: null,
        reservation: null
      }];
      setTables(mockTables);
      setLoading(false);
    };
    loadTables();
  }, []);
  const handleTableAction = table => {
    if (table.status === 'occupied') {
      // Navigate directly to edit order instead of showing payment options
      navigate(`/ordenes?table=${table.id}`);
    } else if (table.status === 'available') {
      // Create new order
      navigate(`/ordenes?table=${table.id}&new=true`);
    } else if (table.status === 'reserved') {
      showToast('info', `Mesa reservada para ${table.reservation.name} a las ${table.reservation.time}`);
    }
  };
  const filteredTables = tables.filter(table => {
    if (filter === 'all') return true;
    return table.status === filter;
  });
  const getStatusBadge = status => {
    const styles = {
      occupied: 'bg-amber-100 text-amber-800 border-amber-200',
      available: 'bg-green-100 text-green-800 border-green-200',
      reserved: 'bg-blue-100 text-blue-800 border-blue-200'
    };
    const labels = {
      occupied: 'Ocupada',
      available: 'Disponible',
      reserved: 'Reservada'
    };
    return <span className={`text-xs px-2 py-1 rounded-full border ${styles[status]}`}>
        {labels[status]}
      </span>;
  };
  return <div className="h-full">
      <h1 className="text-2xl font-bold mb-4">Mesas</h1>
      {/* Filtros y controles */}
      <div className="flex flex-wrap justify-between items-center mb-4 gap-2">
        <div className="flex flex-wrap gap-2">
          <button className={`px-3 py-1.5 text-xs sm:text-sm rounded-full ${filter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`} onClick={() => setFilter('all')}>
            Todas
          </button>
          <button className={`px-3 py-1.5 text-xs sm:text-sm rounded-full ${filter === 'available' ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-700'}`} onClick={() => setFilter('available')}>
            Disponibles
          </button>
          <button className={`px-3 py-1.5 text-xs sm:text-sm rounded-full ${filter === 'occupied' ? 'bg-amber-600 text-white' : 'bg-gray-100 text-gray-700'}`} onClick={() => setFilter('occupied')}>
            Ocupadas
          </button>
          <button className={`px-3 py-1.5 text-xs sm:text-sm rounded-full ${filter === 'reserved' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`} onClick={() => setFilter('reserved')}>
            Reservadas
          </button>
        </div>
      </div>
      {/* Grid de mesas */}
      {loading ? <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4, 5, 6].map(i => <div key={i} className="bg-gray-200 animate-pulse h-40 rounded-xl"></div>)}
        </div> : <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {filteredTables.map(table => <div key={table.id} onClick={() => handleTableAction(table)} className={`bg-white rounded-xl shadow-sm border border-gray-200 p-3 flex flex-col h-40 hover:shadow-md transition-shadow cursor-pointer overflow-hidden ${table.status === 'occupied' ? 'border-amber-300' : table.status === 'reserved' ? 'border-blue-300' : 'border-green-300'}`}>
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-medium text-gray-800">{table.name}</h3>
                {getStatusBadge(table.status)}
              </div>
              <div className="text-xs text-gray-500 flex items-center mb-1">
                <UserIcon size={12} className="mr-1" /> {table.seats} personas
              </div>
              {table.waiter && <div className="text-xs text-gray-500 flex items-center mb-1">
                  <UserCircleIcon size={12} className="mr-1" />
                  <span className="font-medium">{table.waiter.name}</span>
                </div>}
              <div className="flex-grow w-full">
                {table.status === 'occupied' && table.order && <div className="mt-2 bg-amber-50 p-2 rounded-lg w-full max-w-full overflow-hidden">
                    <div className="text-xs text-gray-700 font-medium truncate">
                      {table.order.id}
                    </div>
                    {table.order.customerName && <div className="text-xs text-gray-600 font-medium truncate">
                        Cliente: {table.order.customerName}
                      </div>}
                    <div className="flex justify-between mt-1">
                      <div className="text-xs text-gray-600 whitespace-nowrap">
                        {table.order.items} productos
                      </div>
                      <div className="text-xs text-gray-600 whitespace-nowrap">
                        <ClockIcon size={12} className="inline mr-1" />
                        {table.order.time}
                      </div>
                    </div>
                    <div className="mt-2 text-sm font-medium text-gray-800 truncate">
                      $
                      {new Intl.NumberFormat('es-CO').format(table.order.total)}
                    </div>
                  </div>}
                {table.status === 'reserved' && table.reservation && <div className="mt-2 bg-blue-50 p-2 rounded-lg w-full max-w-full overflow-hidden">
                    <div className="text-xs text-gray-700 font-medium truncate">
                      {table.reservation.name}
                    </div>
                    <div className="flex justify-between mt-1">
                      <div className="text-xs text-gray-600 whitespace-nowrap">
                        <UserIcon size={12} className="inline mr-1" />
                        {table.reservation.people}
                      </div>
                      <div className="text-xs text-gray-600 whitespace-nowrap">
                        <ClockIcon size={12} className="inline mr-1" />
                        {table.reservation.time}
                      </div>
                    </div>
                  </div>}
                {table.status === 'available' && <div className="flex items-center justify-center h-full">
                    <button className="bg-green-100 text-green-800 px-3 py-1.5 rounded-lg text-xs">
                      <PlusIcon size={12} className="inline mr-1" />
                      Nueva orden
                    </button>
                  </div>}
              </div>
            </div>)}
        </div>}
    </div>;
};
export default TablesPage;