import React, { useState } from 'react';
import { DollarSignIcon, CreditCardIcon, PrinterIcon, ReceiptIcon, CheckIcon, XIcon, PlusIcon, SearchIcon, ArrowRightIcon } from 'lucide-react';
import ClientSelector from '../../components/ClientSelector';
// Mock data for active tickets
const mockTickets = [{
  id: 'T001',
  table: 5,
  items: [{
    id: 1,
    name: 'Hamburguesa Clásica',
    price: 12000,
    quantity: 2
  }, {
    id: 2,
    name: 'Papas Fritas',
    price: 5000,
    quantity: 1
  }, {
    id: 3,
    name: 'Refresco Cola',
    price: 3500,
    quantity: 2
  }],
  status: 'active',
  waiter: 'Carlos',
  created: '2023-06-15T14:30:00',
  subtotal: 36000,
  tax: 6840,
  total: 42840
}, {
  id: 'T002',
  table: 8,
  items: [{
    id: 4,
    name: 'Pizza Margarita',
    price: 18000,
    quantity: 1
  }, {
    id: 5,
    name: 'Ensalada César',
    price: 9000,
    quantity: 1
  }, {
    id: 6,
    name: 'Agua Mineral',
    price: 2500,
    quantity: 2
  }],
  status: 'active',
  waiter: 'María',
  created: '2023-06-15T15:10:00',
  subtotal: 32000,
  tax: 6080,
  total: 38080
}];
const paymentMethods = [{
  id: 'cash',
  name: 'Efectivo',
  icon: <DollarSignIcon size={20} />
}, {
  id: 'card',
  name: 'Tarjeta',
  icon: <CreditCardIcon size={20} />
}, {
  id: 'transfer',
  name: 'Transferencia',
  icon: <ArrowRightIcon size={20} />
}];
const CashRegisterPage = () => {
  const [activeTickets, setActiveTickets] = useState(mockTickets);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('cash');
  const [showClientSelector, setShowClientSelector] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  // Calculate total
  const calculateTotal = ticket => {
    if (!ticket) return 0;
    return ticket.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  };
  // Handle ticket selection
  const handleSelectTicket = ticket => {
    setSelectedTicket(ticket);
    setPaymentAmount(ticket.total.toString());
  };
  // Handle payment process
  const handlePayment = () => {
    // In a real app, this would process the payment
    setActiveTickets(activeTickets.filter(ticket => ticket.id !== selectedTicket.id));
    setSelectedTicket(null);
    setShowPaymentModal(false);
    setSelectedClient(null);
  };
  // Handle client selection
  const handleSelectClient = client => {
    setSelectedClient(client);
    setShowClientSelector(false);
  };
  return <div className="w-full bg-white">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Caja Registradora</h1>
        <p className="text-gray-600 mt-1">Gestión de pagos y cuentas</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tickets List */}
        <div className="lg:col-span-2">
          <div className="bg-white border border-gray-200 rounded-lg shadow-sm">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-800">
                Cuentas Activas
              </h2>
            </div>
            <div className="p-4">
              <div className="flex mb-4">
                <div className="relative flex-1">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <SearchIcon size={18} className="text-gray-400" />
                  </div>
                  <input type="text" className="pl-10 block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Buscar cuenta por mesa o número" />
                </div>
                <button className="ml-2 bg-gray-100 text-gray-800 px-3 py-2 rounded-lg hover:bg-gray-200 flex items-center">
                  <SearchIcon size={16} className="mr-1" />
                  <span>Buscar</span>
                </button>
              </div>
              {activeTickets.length > 0 ? <div className="space-y-4">
                  {activeTickets.map(ticket => <div key={ticket.id} className={`border rounded-lg p-4 cursor-pointer transition-colors ${selectedTicket?.id === ticket.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300'}`} onClick={() => handleSelectTicket(ticket)}>
                      <div className="flex justify-between items-center mb-2">
                        <div className="flex items-center">
                          <div className="bg-blue-100 text-blue-600 p-2 rounded-md">
                            <ReceiptIcon size={20} />
                          </div>
                          <div className="ml-3">
                            <h3 className="font-medium text-gray-900">
                              Cuenta #{ticket.id}
                            </h3>
                            <p className="text-sm text-gray-500">
                              Mesa {ticket.table} • Mesero: {ticket.waiter}
                            </p>
                          </div>
                        </div>
                        <span className="font-bold text-gray-900">
                          ${ticket.total.toLocaleString()}
                        </span>
                      </div>
                      <div className="text-sm text-gray-600">
                        <p>
                          {ticket.items.length} productos •{' '}
                          {ticket.items.reduce((sum, item) => sum + item.quantity, 0)}{' '}
                          items
                        </p>
                      </div>
                    </div>)}
                </div> : <div className="text-center py-8 text-gray-500">
                  <ReceiptIcon size={48} className="mx-auto mb-3 text-gray-300" />
                  <p>No hay cuentas activas</p>
                </div>}
            </div>
          </div>
        </div>

        {/* Payment Panel */}
        <div className="lg:col-span-1">
          <div className="bg-white border border-gray-200 rounded-lg shadow-sm h-full">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-800">
                Detalles de Pago
              </h2>
            </div>
            {selectedTicket ? <div className="p-4">
                <div className="mb-4">
                  <p className="text-sm text-gray-500 mb-1">
                    Cuenta seleccionada
                  </p>
                  <div className="flex justify-between items-center">
                    <p className="font-medium">
                      {selectedTicket.id} - Mesa {selectedTicket.table}
                    </p>
                    <button onClick={() => setSelectedTicket(null)} className="text-gray-400 hover:text-gray-500">
                      <XIcon size={16} />
                    </button>
                  </div>
                </div>
                <div className="mb-4 border-t border-gray-200 pt-4">
                  <h3 className="font-medium mb-2">Detalle de productos</h3>
                  <ul className="space-y-2">
                    {selectedTicket.items.map(item => <li key={item.id} className="flex justify-between text-sm">
                        <span>
                          {item.quantity}x {item.name}
                        </span>
                        <span>
                          ${(item.price * item.quantity).toLocaleString()}
                        </span>
                      </li>)}
                  </ul>
                </div>
                <div className="mb-6 border-t border-gray-200 pt-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Subtotal</span>
                    <span>${selectedTicket.subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">IVA (19%)</span>
                    <span>${selectedTicket.tax.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span>${selectedTicket.total.toLocaleString()}</span>
                  </div>
                </div>
                <div className="mb-4">
                  <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 font-medium flex items-center justify-center" onClick={() => setShowPaymentModal(true)}>
                    <DollarSignIcon size={18} className="mr-2" />
                    Procesar Pago
                  </button>
                </div>
                <div className="flex space-x-2">
                  <button className="flex-1 bg-gray-100 text-gray-700 py-2 px-3 rounded-lg hover:bg-gray-200 text-sm flex items-center justify-center">
                    <PrinterIcon size={16} className="mr-1" />
                    Imprimir
                  </button>
                  <button className="flex-1 bg-gray-100 text-gray-700 py-2 px-3 rounded-lg hover:bg-gray-200 text-sm flex items-center justify-center" onClick={() => setShowClientSelector(true)}>
                    <PlusIcon size={16} className="mr-1" />
                    Cliente
                  </button>
                </div>
                {selectedClient && <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-gray-900">
                          {selectedClient.name}
                        </p>
                        <p className="text-sm text-gray-600">
                          {selectedClient.documentType}:{' '}
                          {selectedClient.document}
                        </p>
                        {selectedClient.address && <p className="text-xs text-gray-500 mt-1">
                            {selectedClient.address}
                          </p>}
                      </div>
                      <button onClick={() => setSelectedClient(null)} className="text-gray-400 hover:text-gray-500">
                        <XIcon size={14} />
                      </button>
                    </div>
                  </div>}
              </div> : <div className="p-4 text-center">
                <div className="py-8">
                  <ReceiptIcon size={48} className="mx-auto mb-3 text-gray-300" />
                  <p className="text-gray-500">
                    Selecciona una cuenta para procesar el pago
                  </p>
                </div>
              </div>}
          </div>
        </div>
      </div>

      {/* Payment Modal */}
      {showPaymentModal && selectedTicket && <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md mx-4">
            <div className="p-4 border-b border-gray-200">
              <h3 className="text-lg font-medium text-gray-900">
                Procesar Pago
              </h3>
            </div>
            <div className="p-4">
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Cuenta
                </label>
                <p className="text-gray-900">
                  #{selectedTicket.id} - Mesa {selectedTicket.table}
                </p>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Total a Pagar
                </label>
                <input type="text" value={paymentAmount} onChange={e => setPaymentAmount(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Método de Pago
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {paymentMethods.map(method => <button key={method.id} className={`p-3 rounded-lg flex flex-col items-center justify-center border ${selectedPaymentMethod === method.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300'}`} onClick={() => setSelectedPaymentMethod(method.id)}>
                      <div className={`p-2 rounded-full ${selectedPaymentMethod === method.id ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'}`}>
                        {method.icon}
                      </div>
                      <span className="text-sm mt-1">{method.name}</span>
                    </button>)}
                </div>
              </div>
              <div className="flex space-x-3">
                <button className="flex-1 bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 font-medium" onClick={() => setShowPaymentModal(false)}>
                  Cancelar
                </button>
                <button className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 font-medium flex items-center justify-center" onClick={handlePayment}>
                  <CheckIcon size={18} className="mr-2" />
                  Confirmar Pago
                </button>
              </div>
            </div>
          </div>
        </div>}

      {/* Client Selector Modal */}
      {showClientSelector && <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md mx-4">
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="text-lg font-medium text-gray-900">
                Seleccionar Cliente
              </h3>
              <button onClick={() => setShowClientSelector(false)} className="text-gray-400 hover:text-gray-500">
                <XIcon size={20} />
              </button>
            </div>
            <div className="p-4">
              <ClientSelector onSelectClient={handleSelectClient} />
            </div>
          </div>
        </div>}
    </div>;
};
export default CashRegisterPage;