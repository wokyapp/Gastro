import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { PlusIcon, TrashIcon, CheckIcon, SearchIcon, FilterIcon, UtensilsIcon, GlassWaterIcon, TagIcon, LayersIcon, ChevronRightIcon, ChevronDownIcon, ClockIcon, PackageIcon, UserCircleIcon, ChevronUpIcon, EyeIcon, EyeOffIcon } from 'lucide-react';
import { useToast } from '../../contexts/ToastContext';
import OrderTypeSelector from '../../components/OrderTypeSelector';
// Tipos de orden y estados
type OrderType = 'mesa' | 'llevar';
type OrderStatus = 'borrador' | 'enviada' | 'preparando' | 'lista' | 'facturada' | 'pagada' | 'cancelada';
// Interfaz para las órdenes
interface Order {
  id: string;
  type: OrderType;
  tableId?: number;
  tableName?: string;
  customerName?: string;
  customerPhone?: string;
  pickupTime?: string;
  items: any[];
  total: number;
  status: OrderStatus;
  createdAt: Date;
  updatedAt: Date;
  waiter?: any;
}
// Interfaz para las mesas
interface Table {
  id: number;
  name: string;
  seats: number;
  status: 'available' | 'occupied' | 'reserved';
  waiter?: any;
  order?: Order | null;
}
// Tipo para producto
type ProductType = {
  id: string;
  name: string;
  icon: string;
  color: string;
};
// Tipo para categorías del menú
type MenuCategory = {
  id: string;
  name: string;
  type: string;
  order: number;
};
// Tipo para ítems del menú
interface MenuItem {
  id: number;
  name: string;
  price: number;
  category: string;
  type?: string;
  description?: string;
  image?: string;
  preparationTime?: number;
  available?: boolean;
  isCombo?: boolean;
  comboItems?: string[];
}
// Tipo para meseros
interface Waiter {
  id: number;
  name: string;
  active: boolean;
}
const OrdersPage = () => {
  const {
    showToast
  } = useToast();
  const location = useLocation();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const tableId = queryParams.get('table');
  const isNewOrder = queryParams.get('new') === 'true';
  // Estados
  const [orderType, setOrderType] = useState<OrderType>(tableId ? 'mesa' : 'llevar');
  const [selectedTable, setSelectedTable] = useState<Table | null>(null);
  const [availableTables, setAvailableTables] = useState<Table[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [selectedItems, setSelectedItems] = useState<(MenuItem & {
    quantity: number;
  })[]>([]);
  const [loading, setLoading] = useState(true);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [pickupTime, setPickupTime] = useState('');
  const [activeOrders, setActiveOrders] = useState<Order[]>([]);
  const [menuSearchTerm, setMenuSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const [existingOrder, setExistingOrder] = useState<Order | null>(null);
  const [selectedWaiter, setSelectedWaiter] = useState<Waiter | null>(null);
  const [allCategoriesExpanded, setAllCategoriesExpanded] = useState(true);
  // Lista de meseros (simulada)
  const [waiters, setWaiters] = useState<Waiter[]>([{
    id: 1,
    name: 'Carlos Rodríguez',
    active: true
  }, {
    id: 2,
    name: 'María López',
    active: true
  }, {
    id: 3,
    name: 'Juan Pérez',
    active: true
  }, {
    id: 4,
    name: 'Ana García',
    active: false
  }]);
  // Datos de ejemplo para tipos de productos (igual que en MenuPage)
  const [productTypes, setProductTypes] = useState<ProductType[]>([{
    id: 'food',
    name: 'Comidas',
    icon: 'UtensilsIcon',
    color: 'amber'
  }, {
    id: 'drink',
    name: 'Bebidas',
    icon: 'GlassWaterIcon',
    color: 'blue'
  }, {
    id: 'dessert',
    name: 'Postres',
    icon: 'CakeIcon',
    color: 'pink'
  }]);
  // Datos de ejemplo para categorías del menú (igual que en MenuPage)
  const [menuCategories, setMenuCategories] = useState<MenuCategory[]>([{
    id: 'cat-1',
    name: 'Entradas',
    type: 'food',
    order: 1
  }, {
    id: 'cat-2',
    name: 'Platos Fuertes',
    type: 'food',
    order: 2
  }, {
    id: 'cat-3',
    name: 'Postres',
    type: 'food',
    order: 3
  }, {
    id: 'cat-4',
    name: 'Bebidas Frías',
    type: 'drink',
    order: 1
  }, {
    id: 'cat-5',
    name: 'Bebidas Calientes',
    type: 'drink',
    order: 2
  }, {
    id: 'cat-6',
    name: 'Cervezas',
    type: 'drink',
    order: 3
  }, {
    id: 'cat-7',
    name: 'Vinos',
    type: 'drink',
    order: 4
  }]);
  useEffect(() => {
    const loadData = async () => {
      // Simulación de carga de datos
      await new Promise(resolve => setTimeout(resolve, 800));
      // Cargar mesas disponibles
      const mockAvailableTables: Table[] = [{
        id: 1,
        name: 'Mesa 1',
        seats: 4,
        status: 'occupied',
        waiter: {
          id: 1,
          name: 'Carlos Rodríguez'
        },
        order: {
          id: 'ORD-001',
          type: 'mesa',
          tableId: 1,
          tableName: 'Mesa 1',
          items: [{
            id: 1,
            name: 'Hamburguesa Clásica',
            price: 18000,
            quantity: 2
          }, {
            id: 3,
            name: 'Cerveza Artesanal',
            price: 12000,
            quantity: 1
          }],
          total: 48000,
          status: 'preparando',
          createdAt: new Date(Date.now() - 30 * 60000),
          updatedAt: new Date(Date.now() - 20 * 60000),
          waiter: {
            id: 1,
            name: 'Carlos Rodríguez'
          }
        }
      }, {
        id: 2,
        name: 'Mesa 2',
        seats: 2,
        status: 'available'
      }, {
        id: 3,
        name: 'Mesa 3',
        seats: 6,
        status: 'occupied',
        waiter: {
          id: 2,
          name: 'María López'
        },
        order: {
          id: 'ORD-002',
          type: 'mesa',
          tableId: 3,
          tableName: 'Mesa 3',
          items: [{
            id: 8,
            name: 'Pizza Margarita',
            price: 22000,
            quantity: 2
          }, {
            id: 5,
            name: 'Agua Mineral',
            price: 5000,
            quantity: 1
          }, {
            id: 11,
            name: 'Nachos con Guacamole',
            price: 18000,
            quantity: 2
          }],
          total: 87200,
          status: 'preparando',
          createdAt: new Date(Date.now() - 15 * 60000),
          updatedAt: new Date(Date.now() - 10 * 60000),
          waiter: {
            id: 2,
            name: 'María López'
          }
        }
      }, {
        id: 4,
        name: 'Mesa 4',
        seats: 4,
        status: 'reserved',
        waiter: {
          id: 3,
          name: 'Juan Pérez'
        }
      }, {
        id: 5,
        name: 'Mesa 5',
        seats: 8,
        status: 'available'
      }, {
        id: 6,
        name: 'Mesa 6',
        seats: 2,
        status: 'reserved',
        waiter: {
          id: 1,
          name: 'Carlos Rodríguez'
        }
      }, {
        id: 7,
        name: 'Terraza 1',
        seats: 4,
        status: 'available'
      }, {
        id: 8,
        name: 'Terraza 2',
        seats: 4,
        status: 'available'
      }];
      setAvailableTables(mockAvailableTables);
      // Cargar datos de mesa si se especificó una
      if (tableId) {
        const tableIdNum = parseInt(tableId);
        const table = mockAvailableTables.find(t => t.id === tableIdNum);
        if (table) {
          setSelectedTable(table);
          // Si la mesa tiene una orden existente y no es una orden nueva
          if (table.order && !isNewOrder) {
            setExistingOrder(table.order);
            // Cargar los items de la orden existente
            const orderItems = table.order.items.map(item => ({
              ...item,
              category: getItemCategory(item.id),
              type: getItemType(item.id),
              description: getItemDescription(item.id)
            }));
            setSelectedItems(orderItems);
            // Establecer el mesero de la orden
            if (table.order.waiter) {
              setSelectedWaiter(table.order.waiter);
            }
          } else if (table.waiter) {
            // Si es una orden nueva pero la mesa ya tiene mesero asignado
            setSelectedWaiter(table.waiter);
          }
        }
      }
      // Cargar menú de ejemplo con tipos y categorías
      const mockMenuItems = [{
        id: 1,
        name: 'Hamburguesa Clásica',
        price: 18000,
        category: 'cat-2',
        type: 'food',
        description: 'Carne de res, queso, lechuga, tomate y cebolla',
        preparationTime: 20
      }, {
        id: 2,
        name: 'Papas Fritas',
        price: 8000,
        category: 'cat-1',
        type: 'food',
        description: 'Papas fritas con sal',
        preparationTime: 10
      }, {
        id: 3,
        name: 'Cerveza Artesanal',
        price: 12000,
        category: 'cat-6',
        type: 'drink',
        description: 'Cerveza artesanal local'
      }, {
        id: 4,
        name: 'Ensalada César',
        price: 15000,
        category: 'cat-1',
        type: 'food',
        description: 'Lechuga romana, crutones, pollo y aderezo césar',
        preparationTime: 10
      }, {
        id: 5,
        name: 'Agua Mineral',
        price: 5000,
        category: 'cat-4',
        type: 'drink',
        description: 'Agua mineral natural'
      }, {
        id: 6,
        name: 'Café Americano',
        price: 6000,
        category: 'cat-5',
        type: 'drink',
        description: 'Café americano recién preparado'
      }, {
        id: 7,
        name: 'Postre del Día',
        price: 9000,
        category: 'cat-3',
        type: 'dessert',
        description: 'Postre especial del chef'
      }, {
        id: 8,
        name: 'Pizza Margarita',
        price: 22000,
        category: 'cat-2',
        type: 'food',
        description: 'Pizza con salsa de tomate, queso mozzarella y albahaca',
        preparationTime: 25
      }, {
        id: 9,
        name: 'Sopa del Día',
        price: 10000,
        category: 'cat-1',
        type: 'food',
        description: 'Sopa casera del día',
        preparationTime: 15
      }, {
        id: 10,
        name: 'Vino Tinto',
        price: 15000,
        category: 'cat-7',
        type: 'drink',
        description: 'Copa de vino tinto de la casa'
      }, {
        id: 11,
        name: 'Nachos con Guacamole',
        price: 18000,
        category: 'cat-1',
        type: 'food',
        description: 'Nachos crujientes con guacamole fresco',
        preparationTime: 10
      }, {
        id: 12,
        name: 'Combo Hamburguesa',
        price: 32000,
        category: 'cat-2',
        type: 'food',
        description: 'Hamburguesa + Papas + Bebida',
        preparationTime: 20,
        isCombo: true,
        comboItems: ['1', '2', '5']
      }];
      setMenuItems(mockMenuItems);
      // Inicializar las categorías expandidas
      const initialExpanded: Record<string, boolean> = {};
      menuCategories.forEach(cat => {
        initialExpanded[cat.id] = true;
      });
      setExpandedCategories(initialExpanded);
      // Cargar órdenes activas (simulación) - solo para referencia interna
      const mockActiveOrders: Order[] = [{
        id: 'ORD-001',
        type: 'mesa',
        tableId: 1,
        tableName: 'Mesa 1',
        items: [{
          id: 1,
          name: 'Hamburguesa Clásica',
          price: 18000,
          quantity: 2
        }, {
          id: 3,
          name: 'Cerveza Artesanal',
          price: 12000,
          quantity: 1
        }],
        total: 48000,
        status: 'preparando',
        createdAt: new Date(Date.now() - 30 * 60000),
        updatedAt: new Date(Date.now() - 20 * 60000),
        waiter: {
          id: 1,
          name: 'Carlos Rodríguez'
        }
      }, {
        id: 'ORD-002',
        type: 'mesa',
        tableId: 3,
        tableName: 'Mesa 3',
        items: [{
          id: 8,
          name: 'Pizza Margarita',
          price: 22000,
          quantity: 2
        }, {
          id: 5,
          name: 'Agua Mineral',
          price: 5000,
          quantity: 1
        }, {
          id: 11,
          name: 'Nachos con Guacamole',
          price: 18000,
          quantity: 2
        }],
        total: 87200,
        status: 'preparando',
        createdAt: new Date(Date.now() - 15 * 60000),
        updatedAt: new Date(Date.now() - 10 * 60000),
        waiter: {
          id: 2,
          name: 'María López'
        }
      }];
      setActiveOrders(mockActiveOrders);
      setLoading(false);
    };
    loadData();
  }, [tableId, isNewOrder]);
  // Filter tables to only show available ones for new orders
  const availableTablesForSelection = availableTables.filter(table => table.status === 'available' || !isNewOrder && table.id === parseInt(tableId));
  // Funciones auxiliares para obtener información de los items
  const getItemCategory = (itemId: number): string => {
    const item = menuItems.find(i => i.id === itemId);
    return item?.category || '';
  };
  const getItemType = (itemId: number): string | undefined => {
    const item = menuItems.find(i => i.id === itemId);
    return item?.type;
  };
  const getItemDescription = (itemId: number): string | undefined => {
    const item = menuItems.find(i => i.id === itemId);
    return item?.description;
  };
  const handleOrderTypeChange = (type: OrderType) => {
    setOrderType(type);
    // Limpiar la selección de mesa si cambia a llevar
    if (type === 'llevar') {
      setSelectedTable(null);
      setSelectedWaiter(null);
    }
  };
  const selectTable = (table: Table) => {
    if (table.status !== 'available' && isNewOrder) {
      showToast('error', `${table.name} no está disponible`);
      return;
    }
    setSelectedTable(table);
    // Si la mesa ya tiene un mesero asignado
    if (table.waiter) {
      setSelectedWaiter(table.waiter);
    }
    // Si la mesa ya tiene una orden y no es una orden nueva
    if (table.order && !isNewOrder) {
      setExistingOrder(table.order);
      // Cargar los items de la orden existente
      const orderItems = table.order.items.map(item => ({
        ...item,
        category: getItemCategory(item.id),
        type: getItemType(item.id),
        description: getItemDescription(item.id)
      }));
      setSelectedItems(orderItems);
    }
  };
  const addItemToOrder = (item: MenuItem) => {
    const existingItem = selectedItems.find(i => i.id === item.id);
    if (existingItem) {
      setSelectedItems(selectedItems.map(i => i.id === item.id ? {
        ...i,
        quantity: i.quantity + 1
      } : i));
    } else {
      setSelectedItems([...selectedItems, {
        ...item,
        quantity: 1
      }]);
    }
  };
  const removeItemFromOrder = (itemId: number) => {
    setSelectedItems(selectedItems.filter(item => item.id !== itemId));
  };
  const updateItemQuantity = (itemId: number, quantity: number) => {
    if (quantity <= 0) {
      removeItemFromOrder(itemId);
      return;
    }
    setSelectedItems(selectedItems.map(item => item.id === itemId ? {
      ...item,
      quantity
    } : item));
  };
  const calculateTotal = () => {
    return selectedItems.reduce((total, item) => total + item.price * item.quantity, 0);
  };
  // Enviar orden a cocina
  const handleSubmitOrder = () => {
    if (selectedItems.length === 0) {
      showToast('error', 'La orden debe tener al menos un producto');
      return;
    }
    if (orderType === 'mesa' && !selectedTable) {
      showToast('error', 'Debes seleccionar una mesa');
      return;
    }
    if (orderType === 'mesa' && !selectedWaiter) {
      showToast('error', 'Debes asignar un mesero a la orden');
      return;
    }
    if (orderType === 'mesa' && !customerName.trim()) {
      showToast('error', 'Ingresa el nombre del cliente para la mesa');
      return;
    }
    if (orderType === 'llevar' && !customerName.trim()) {
      showToast('error', 'Ingresa el nombre del cliente');
      return;
    }
    // Si es una actualización de orden existente
    if (existingOrder) {
      // Actualizar la orden existente
      const updatedOrder = {
        ...existingOrder,
        items: [...selectedItems],
        total: calculateTotal(),
        updatedAt: new Date(),
        waiter: selectedWaiter,
        customerName: customerName
      };
      // Actualizar la lista de órdenes activas
      setActiveOrders(activeOrders.map(order => order.id === existingOrder.id ? updatedOrder : order));
      // Actualizar la orden en la mesa
      setAvailableTables(availableTables.map(table => table.id === updatedOrder.tableId ? {
        ...table,
        order: updatedOrder
      } : table));
      showToast('success', `Orden ${existingOrder.id} actualizada y enviada a cocina`);
      navigate('/mesas');
      return;
    }
    // Crear nueva orden
    const newOrder: Order = {
      id: `ORD-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
      type: orderType,
      items: [...selectedItems],
      total: calculateTotal(),
      status: 'enviada',
      createdAt: new Date(),
      updatedAt: new Date(),
      waiter: selectedWaiter,
      customerName: customerName
    };
    // Añadir datos según tipo de orden
    if (orderType === 'mesa' && selectedTable) {
      newOrder.tableId = selectedTable.id;
      newOrder.tableName = selectedTable.name;
    } else {
      newOrder.customerPhone = customerPhone;
      newOrder.pickupTime = pickupTime;
    }
    // Añadir a órdenes activas
    setActiveOrders([...activeOrders, newOrder]);
    // Mostrar notificación de éxito
    showToast('success', orderType === 'mesa' ? `Orden enviada a cocina para ${selectedTable?.name} (Cliente: ${customerName})` : `Orden para llevar enviada a cocina para ${customerName}`);
    // Actualizar el estado de la mesa a ocupada
    if (orderType === 'mesa' && selectedTable) {
      setAvailableTables(availableTables.map(table => table.id === selectedTable.id ? {
        ...table,
        status: 'occupied' as 'occupied',
        order: newOrder,
        waiter: selectedWaiter
      } : table));
    }
    // Limpiar formulario
    setSelectedItems([]);
    if (orderType === 'llevar') {
      setCustomerName('');
      setCustomerPhone('');
      setPickupTime('');
      setSelectedWaiter(null);
    } else {
      setSelectedTable(null);
      setSelectedWaiter(null);
      setCustomerName('');
    }
    // Redirigir a la página de mesas
    navigate('/mesas');
  };
  // Get icon component by name (igual que en MenuPage)
  const getIconByName = (iconName: string, size = 16, className = '') => {
    switch (iconName) {
      case 'UtensilsIcon':
        return <UtensilsIcon size={size} className={className} />;
      case 'GlassWaterIcon':
        return <GlassWaterIcon size={size} className={className} />;
      case 'CakeIcon':
        return <LayersIcon size={size} className={className} />;
      default:
        return <TagIcon size={size} className={className} />;
    }
  };
  // Filtrar menú por tipo, categoría y término de búsqueda
  const filteredMenuItems = menuItems.filter(item => {
    const matchesSearch = menuSearchTerm === '' || item.name.toLowerCase().includes(menuSearchTerm.toLowerCase()) || item.description && item.description.toLowerCase().includes(menuSearchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || item.type === selectedType;
    const matchesCategory = selectedCategory === '' || item.category === selectedCategory;
    return matchesSearch && matchesType && matchesCategory;
  });
  // Categorías filtradas por tipo seleccionado
  const filteredCategories = menuCategories.filter(cat => selectedType === 'all' || cat.type === selectedType).sort((a, b) => a.order - b.order);
  // Agrupar productos por categoría
  const groupedMenuItems: Record<string, MenuItem[]> = {};
  filteredMenuItems.forEach(item => {
    if (!groupedMenuItems[item.category]) {
      groupedMenuItems[item.category] = [];
    }
    groupedMenuItems[item.category].push(item);
  });
  // Función para alternar la expansión de categorías
  const toggleCategoryExpansion = (categoryId: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryId]: !prev[categoryId]
    }));
  };
  // Función para expandir o colapsar todas las categorías
  const toggleAllCategories = () => {
    const newState = !allCategoriesExpanded;
    setAllCategoriesExpanded(newState);
    const updatedExpanded: Record<string, boolean> = {};
    filteredCategories.forEach(cat => {
      updatedExpanded[cat.id] = newState;
    });
    setExpandedCategories(updatedExpanded);
  };
  // Estilos para botones
  const softBtn = (color: string) => {
    const colorMap: Record<string, string> = {
      blue: 'bg-blue-50 text-blue-700 hover:bg-blue-100',
      gray: 'bg-gray-50 text-gray-700 hover:bg-gray-100',
      amber: 'bg-amber-50 text-amber-700 hover:bg-amber-100',
      red: 'bg-red-50 text-red-700 hover:bg-red-100',
      green: 'bg-green-50 text-green-700 hover:bg-green-100',
      purple: 'bg-purple-50 text-purple-700 hover:bg-purple-100',
      pink: 'bg-pink-50 text-pink-700 hover:bg-pink-100'
    };
    return `px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center ${colorMap[color] || colorMap.gray}`;
  };
  return <div className="p-4">
      {/* Header con el mismo estilo que el título principal */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-4 rounded-xl mb-4 shadow-md flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">
            {existingOrder ? 'Editar Orden' : 'Nueva Orden'}
          </h1>
          <p className="text-sm opacity-90">
            {existingOrder ? `Modificando orden ${existingOrder.id}` : 'Creación de órdenes'}
          </p>
        </div>
        <div className="flex space-x-2">
          <button className="px-4 py-2 bg-blue-500 text-white rounded-md text-sm font-medium hover:bg-blue-400 flex items-center" onClick={() => navigate('/cocina')}>
            <UtensilsIcon size={16} className="mr-1" />
            Ir a Cocina
          </button>
        </div>
      </div>
      {loading ? <div className="flex justify-center my-8">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div> :
    // Vista de creación de orden
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Panel izquierdo: Selección de tipo de orden y detalles */}
          <div className="md:col-span-1 space-y-4">
            <div className="bg-white rounded-xl shadow p-4">
              {/* Selector de tipo de orden (deshabilitado si es una orden existente) */}
              {!existingOrder && <OrderTypeSelector selectedType={orderType} onTypeChange={handleOrderTypeChange} />}
              {/* Campo para nombre del cliente (siempre visible) */}
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nombre del Cliente
                </label>
                <input type="text" value={customerName} onChange={e => setCustomerName(e.target.value)} className="w-full p-2 border border-gray-300 rounded-md" placeholder="Nombre del cliente" />
              </div>
              {orderType === 'mesa' ? <div className="mt-4">
                  {selectedTable ? <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex justify-between items-center mb-2">
                        <h3 className="font-medium">{selectedTable.name}</h3>
                        {!existingOrder && <button onClick={() => setSelectedTable(null)} className="px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition-colors">
                            Cambiar Mesa
                          </button>}
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <UtensilsIcon size={14} className="mr-1" />
                        <p>
                          Capacidad:{' '}
                          <span className="font-medium">
                            {selectedTable.seats} personas
                          </span>
                        </p>
                      </div>
                      {/* Selección de mesero */}
                      <div className="mt-3">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Mesero Asignado
                        </label>
                        <select className="w-full p-1.5 border border-gray-300 rounded-md text-sm" value={selectedWaiter ? selectedWaiter.id : ''} onChange={e => {
                  const waiterId = parseInt(e.target.value);
                  if (waiterId) {
                    const waiter = waiters.find(w => w.id === waiterId);
                    setSelectedWaiter(waiter);
                  } else {
                    setSelectedWaiter(null);
                  }
                }} disabled={existingOrder !== null}>
                          <option value="">-- Seleccionar mesero --</option>
                          {waiters.filter(waiter => waiter.active).map(waiter => <option key={waiter.id} value={waiter.id}>
                                {waiter.name}
                              </option>)}
                        </select>
                      </div>
                    </div> : <div>
                      <h3 className="font-medium text-gray-700 mb-2">
                        Selecciona una mesa:
                      </h3>
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        {availableTablesForSelection.map(table => <div key={table.id} onClick={() => selectTable(table)} className={`p-2 rounded-md text-center cursor-pointer transition-colors border ${table.status === 'available' ? 'border-green-300 bg-green-50 hover:bg-green-100' : 'border-amber-300 bg-amber-50'}`}>
                            <div className="font-medium text-sm">
                              {table.name}
                            </div>
                            <div className="flex justify-center items-center text-xs space-x-1 mt-1">
                              <UtensilsIcon size={12} />
                              <span>{table.seats} personas</span>
                            </div>
                            <div className="text-xs mt-1">
                              {table.status === 'available' ? '✓ Disponible' : '⚠️ Con orden'}
                            </div>
                            {table.waiter && <div className="text-xs mt-1 text-gray-600">
                                <UserCircleIcon size={10} className="inline mr-1" />
                                {table.waiter.name}
                              </div>}
                          </div>)}
                      </div>
                    </div>}
                </div> : <div className="mt-4 space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Teléfono (opcional)
                    </label>
                    <input type="tel" value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} className="w-full p-2 border border-gray-300 rounded-md" placeholder="Teléfono de contacto" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Hora de Recogida (opcional)
                    </label>
                    <input type="time" value={pickupTime} onChange={e => setPickupTime(e.target.value)} className="w-full p-2 border border-gray-300 rounded-md" />
                  </div>
                  {/* Selección de mesero para llevar */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Atendido por
                    </label>
                    <select className="w-full p-2 border border-gray-300 rounded-md" value={selectedWaiter ? selectedWaiter.id : ''} onChange={e => {
                const waiterId = parseInt(e.target.value);
                if (waiterId) {
                  const waiter = waiters.find(w => w.id === waiterId);
                  setSelectedWaiter(waiter);
                } else {
                  setSelectedWaiter(null);
                }
              }}>
                      <option value="">-- Seleccionar mesero --</option>
                      {waiters.filter(waiter => waiter.active).map(waiter => <option key={waiter.id} value={waiter.id}>
                            {waiter.name}
                          </option>)}
                    </select>
                  </div>
                </div>}
            </div>
            {/* Resumen de la orden */}
            <div className="bg-white rounded-xl shadow p-4">
              <h3 className="font-medium text-lg mb-3">Resumen de Orden</h3>
              {selectedItems.length === 0 ? <p className="text-sm text-gray-500 my-4">
                  No hay productos seleccionados
                </p> : <div className="space-y-3 max-h-80 overflow-y-auto">
                  {selectedItems.map(item => <div key={item.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                      <div className="flex-1">
                        <p className="font-medium">{item.name}</p>
                        <p className="text-sm text-gray-600">
                          ${new Intl.NumberFormat('es-CO').format(item.price)}
                        </p>
                      </div>
                      <div className="flex items-center">
                        <button onClick={() => updateItemQuantity(item.id, item.quantity - 1)} className="px-2 py-1 bg-gray-200 rounded-l">
                          -
                        </button>
                        <span className="px-3 py-1 bg-gray-100">
                          {item.quantity}
                        </span>
                        <button onClick={() => updateItemQuantity(item.id, item.quantity + 1)} className="px-2 py-1 bg-gray-200 rounded-r">
                          +
                        </button>
                        <button onClick={() => removeItemFromOrder(item.id)} className="ml-2 p-1 text-red-500 hover:bg-red-50 rounded">
                          <TrashIcon size={16} />
                        </button>
                      </div>
                    </div>)}
                </div>}
              <div className="mt-4 pt-3 border-t border-gray-200">
                <div className="flex justify-between font-medium">
                  <span>Total:</span>
                  <span>
                    ${new Intl.NumberFormat('es-CO').format(calculateTotal())}
                  </span>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                <button onClick={() => navigate('/mesas')} className="py-2 px-4 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 text-sm font-medium">
                  Cancelar
                </button>
                <button onClick={handleSubmitOrder} disabled={selectedItems.length === 0 || orderType === 'mesa' && !selectedWaiter} className={`py-2 px-4 rounded-lg text-white text-sm font-medium flex items-center justify-center ${selectedItems.length === 0 || orderType === 'mesa' && !selectedWaiter ? 'bg-gray-400' : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700'}`}>
                  <CheckIcon size={16} className="mr-1" />
                  {existingOrder ? 'Actualizar Orden' : 'Enviar a Cocina'}
                </button>
              </div>
            </div>
          </div>
          {/* Panel derecho: Menú de productos */}
          <div className="md:col-span-2">
            <div className="bg-white rounded-xl shadow p-4">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-medium text-lg">Menú</h3>
                <div className="flex items-center gap-2">
                  <button onClick={toggleAllCategories} className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center ${allCategoriesExpanded ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'}`}>
                    {allCategoriesExpanded ? <>
                        <EyeOffIcon size={16} className="mr-1" />
                        Colapsar todo
                      </> : <>
                        <EyeIcon size={16} className="mr-1" />
                        Expandir todo
                      </>}
                  </button>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <SearchIcon size={16} className="text-gray-400" />
                    </div>
                    <input type="text" placeholder="Buscar productos..." value={menuSearchTerm} onChange={e => setMenuSearchTerm(e.target.value)} className="pl-10 pr-4 py-2 border border-gray-300 rounded-md w-64" />
                  </div>
                </div>
              </div>
              {/* Filtros de tipo de producto */}
              <div className="flex overflow-x-auto pb-2 mb-4 space-x-2">
                <button className={softBtn(selectedType === 'all' ? 'blue' : 'gray')} onClick={() => {
              setSelectedType('all');
              setSelectedCategory('');
            }}>
                  Todos
                </button>
                {productTypes.map(type => <button key={type.id} className={softBtn(selectedType === type.id ? type.color : 'gray')} onClick={() => {
              setSelectedType(type.id);
              setSelectedCategory('');
            }}>
                    {getIconByName(type.icon, 14, 'mr-1')} {type.name}
                  </button>)}
              </div>
              {filteredMenuItems.length === 0 ? <p className="text-gray-500 my-8 text-center">
                  No se encontraron productos
                </p> : <div className="space-y-4">
                  {filteredCategories.map(category => {
              // Solo mostrar categorías que tengan productos
              const categoryItems = groupedMenuItems[category.id] || [];
              if (categoryItems.length === 0) return null;
              return <div key={category.id}>
                        <div className="flex items-center justify-between cursor-pointer mb-2 bg-gray-50 p-2 rounded-lg" onClick={() => toggleCategoryExpansion(category.id)}>
                          <h4 className="font-medium text-gray-700">
                            {category.name}
                          </h4>
                          <div className="flex items-center">
                            <span className="text-xs text-gray-500 mr-2">
                              {categoryItems.length} productos
                            </span>
                            {expandedCategories[category.id] ? <ChevronDownIcon size={16} className="text-gray-500" /> : <ChevronRightIcon size={16} className="text-gray-500" />}
                          </div>
                        </div>
                        {expandedCategories[category.id] && <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-2">
                            {categoryItems.map(item => <div key={item.id} className="p-3 border border-gray-200 rounded-lg hover:bg-blue-50 hover:border-blue-200 cursor-pointer transition-colors" onClick={() => addItemToOrder(item)}>
                                <div className="flex justify-between">
                                  <h5 className="font-medium">{item.name}</h5>
                                  <div className="flex items-center">
                                    <span className="text-gray-600 mr-2">
                                      $
                                      {new Intl.NumberFormat('es-CO').format(item.price)}
                                    </span>
                                    <PlusIcon size={18} className="text-blue-600" />
                                  </div>
                                </div>
                                {item.description && <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                                    {item.description}
                                  </p>}
                                <div className="flex items-center mt-1 text-xs text-gray-500">
                                  {item.preparationTime && <span className="flex items-center mr-2">
                                      <ClockIcon size={12} className="mr-1" />
                                      {item.preparationTime} min
                                    </span>}
                                  {item.isCombo && <span className="flex items-center text-blue-600">
                                      <PackageIcon size={12} className="mr-1" />
                                      Combo
                                    </span>}
                                </div>
                              </div>)}
                          </div>}
                      </div>;
            })}
                </div>}
            </div>
          </div>
        </div>}
    </div>;
};
export default OrdersPage;