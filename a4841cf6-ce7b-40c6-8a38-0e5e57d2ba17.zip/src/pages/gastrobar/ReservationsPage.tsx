import React, { useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import { CalendarIcon, UserIcon, CheckIcon, XIcon, PlusIcon, SearchIcon, UserSearchIcon } from 'lucide-react';
import { useToast } from '../../contexts/ToastContext';
// Tipo para reservaciones
type Reservation = {
  id: string;
  name: string;
  phone: string;
  identification?: string;
  date: string;
  time: string;
  guests: number;
  tableId: string;
  tableNumber: number;
  status: 'confirmed' | 'pending' | 'cancelled' | 'completed';
  notes?: string;
};
// Datos de ejemplo para reservaciones
const mockReservations: Reservation[] = [{
  id: 'r1',
  name: 'Carlos Rodríguez',
  phone: '3001234567',
  identification: '1234567890',
  date: new Date().toISOString().split('T')[0],
  time: '19:00',
  guests: 4,
  tableId: 't4',
  tableNumber: 4,
  status: 'confirmed'
}, {
  id: 'r2',
  name: 'María López',
  phone: '3109876543',
  identification: '0987654321',
  date: new Date().toISOString().split('T')[0],
  time: '20:30',
  guests: 2,
  tableId: '',
  tableNumber: 0,
  status: 'pending',
  notes: 'Prefiere mesa cerca de la ventana'
}, {
  id: 'r3',
  name: 'Juan Pérez',
  phone: '3201234567',
  identification: '5678901234',
  date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  time: '19:30',
  guests: 6,
  tableId: 't6',
  tableNumber: 6,
  status: 'confirmed'
}];
const ReservationsPage = () => {
  const {
    showToast
  } = useToast();
  const {
    softBtn,
    ctaGrad
  } = useOutletContext<any>();
  const [reservations, setReservations] = useState<Reservation[]>(mockReservations);
  const [showReservationModal, setShowReservationModal] = useState(false);
  const [reservationFilter, setReservationFilter] = useState<'all' | 'today' | 'upcoming' | 'pending'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  // Filtrar reservaciones
  const filteredReservations = reservations.filter(reservation => {
    const today = new Date().toISOString().split('T')[0];
    // Filtro por estado/fecha
    const matchesStatusFilter = reservationFilter === 'all' || reservationFilter === 'today' && reservation.date === today || reservationFilter === 'upcoming' && reservation.date > today || reservationFilter === 'pending' && reservation.status === 'pending';
    // Filtro por búsqueda (nombre o identificación)
    const matchesSearch = searchTerm === '' || reservation.name.toLowerCase().includes(searchTerm.toLowerCase()) || reservation.identification && reservation.identification.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatusFilter && matchesSearch;
  });
  return <div className="space-y-4">
      <div className="bg-gradient-to-r from-blue-50 via-violet-50 to-pink-50 p-4 rounded-3xl shadow-sm border border-white/60">
        <div className="bg-white/60 p-3 rounded-2xl">
          <h1 className="text-2xl font-bold text-gray-800">Reservaciones</h1>
          <p className="text-sm text-gray-600">
            Gestión de reservas y disponibilidad
          </p>
        </div>
      </div>
      {/* Barra de búsqueda */}
      <div className="relative w-full mb-4">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <SearchIcon size={18} className="text-gray-400" />
        </div>
        <input type="text" placeholder="Buscar por nombre o identificación..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="pl-10 pr-4 py-2.5 w-full border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none shadow-sm" />
        {searchTerm && <button onClick={() => setSearchTerm('')} className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600">
            <XIcon size={16} />
          </button>}
      </div>
      {/* Filtros y acciones */}
      <div className="flex flex-wrap justify-between items-center mb-4">
        <div className="flex flex-nowrap overflow-x-auto space-x-2">
          <button className={softBtn(reservationFilter === 'all' ? 'blue' : 'gray')} onClick={() => setReservationFilter('all')}>
            Todas
          </button>
          <button className={softBtn(reservationFilter === 'today' ? 'green' : 'gray')} onClick={() => setReservationFilter('today')}>
            Hoy
          </button>
          <button className={softBtn(reservationFilter === 'upcoming' ? 'amber' : 'gray')} onClick={() => setReservationFilter('upcoming')}>
            Próximas
          </button>
          <button className={softBtn(reservationFilter === 'pending' ? 'red' : 'gray')} onClick={() => setReservationFilter('pending')}>
            Pendientes
          </button>
        </div>
        <button className={ctaGrad()} onClick={() => setShowReservationModal(true)}>
          <PlusIcon size={16} className="mr-1" />
          Nueva reservación
        </button>
      </div>
      {/* Lista de reservaciones */}
      <div className="space-y-4">
        {filteredReservations.map(reservation => <div key={reservation.id} className="border border-gray-100 rounded-2xl p-4 hover:border-blue-300 transition-colors bg-white shadow-sm">
            <div className="flex justify-between items-start">
              <div className="flex items-start">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-full mr-3 text-white shadow">
                  <UserIcon size={18} />
                </div>
                <div>
                  <h3 className="font-medium">{reservation.name}</h3>
                  <p className="text-sm text-gray-600">{reservation.phone}</p>
                  {reservation.identification && <p className="text-sm text-gray-600 flex items-center">
                      <div size={14} className="mr-1" />
                      ID: {reservation.identification}
                    </p>}
                  <div className="flex items-center mt-1 text-sm text-gray-500">
                    <CalendarIcon size={14} className="mr-1" />
                    {new Date(reservation.date).toLocaleDateString('es-CO')} - {reservation.time}
                  </div>
                  <div className="flex items-center mt-1 text-sm">
                    <UserIcon size={14} className="mr-1 text-gray-500" />
                    <span className="text-gray-500">
                      {reservation.guests} personas
                    </span>
                    {reservation.tableNumber > 0 && <>
                        <span className="mx-1 text-gray-500">•</span>
                        <span className="text-gray-500">
                          Mesa {reservation.tableNumber}
                        </span>
                      </>}
                  </div>
                  {reservation.notes && <p className="text-xs text-gray-500 mt-1 italic">
                      {reservation.notes}
                    </p>}
                </div>
              </div>
              <span className={`
                  px-2 py-0.5 rounded-full text-xs font-medium
                  ${reservation.status === 'confirmed' ? 'bg-green-100 text-green-800' : ''}
                  ${reservation.status === 'pending' ? 'bg-amber-100 text-amber-800' : ''}
                  ${reservation.status === 'cancelled' ? 'bg-red-100 text-red-800' : ''}
                  ${reservation.status === 'completed' ? 'bg-blue-100 text-blue-800' : ''}
                `}>
                {reservation.status === 'confirmed' ? 'Confirmada' : ''}
                {reservation.status === 'pending' ? 'Pendiente' : ''}
                {reservation.status === 'cancelled' ? 'Cancelada' : ''}
                {reservation.status === 'completed' ? 'Completada' : ''}
              </span>
            </div>
            <div className="mt-3 flex flex-nowrap justify-end space-x-2 overflow-x-auto">
              {reservation.status === 'pending' && <button className={softBtn('green')} onClick={() => {
            setReservations(prevReservations => prevReservations.map(res => res.id === reservation.id ? {
              ...res,
              status: 'confirmed'
            } : res));
            showToast('success', 'Reservación confirmada');
          }}>
                  <CheckIcon size={16} className="mr-1" />
                  Confirmar
                </button>}
              {(reservation.status === 'confirmed' || reservation.status === 'pending') && <button className={softBtn('red')} onClick={() => {
            setReservations(prevReservations => prevReservations.map(res => res.id === reservation.id ? {
              ...res,
              status: 'cancelled'
            } : res));
            showToast('info', 'Reservación cancelada');
          }}>
                  <XIcon size={16} className="mr-1" />
                  Cancelar
                </button>}
              {reservation.status === 'confirmed' && new Date(reservation.date).toDateString() === new Date().toDateString() && <button className={ctaGrad()} onClick={() => {
            setReservations(prevReservations => prevReservations.map(res => res.id === reservation.id ? {
              ...res,
              status: 'completed'
            } : res));
            showToast('success', 'Cliente registrado, mesa asignada');
          }}>
                    <UserIcon size={16} className="mr-1" />
                    Registrar llegada
                  </button>}
            </div>
          </div>)}
        {filteredReservations.length === 0 && <div className="text-center py-8 bg-white rounded-2xl shadow-sm border border-gray-100">
            {searchTerm ? <>
                <UserSearchIcon size={40} className="mx-auto text-gray-300 mb-2" />
                <p className="text-gray-500">
                  No se encontraron reservaciones que coincidan con "
                  {searchTerm}"
                </p>
              </> : <>
                <CalendarIcon size={40} className="mx-auto text-gray-300 mb-2" />
                <p className="text-gray-500">
                  No hay reservaciones que coincidan con el filtro seleccionado
                </p>
              </>}
          </div>}
      </div>
      {/* Modal de nueva reservación */}
      {showReservationModal && <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-lg">
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="text-lg font-semibold">Nueva reservación</h3>
              <button className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100" onClick={() => setShowReservationModal(false)}>
                <XIcon size={20} />
              </button>
            </div>
            <div className="p-4">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nombre del cliente
                  </label>
                  <input type="text" className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Nombre completo" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Teléfono
                    </label>
                    <input type="tel" className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Número de contacto" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Identificación
                    </label>
                    <input type="text" className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Cédula o ID" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Fecha
                    </label>
                    <input type="date" className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" defaultValue={new Date().toISOString().split('T')[0]} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Hora
                    </label>
                    <input type="time" className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" defaultValue="19:00" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Personas
                    </label>
                    <input type="number" min="1" className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Cantidad" defaultValue="2" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Mesa
                    </label>
                    <select className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                      <option value="">Asignar después</option>
                      <option value="t1">Mesa 1 (4 pers.)</option>
                      <option value="t6">Mesa 6 (8 pers.)</option>
                      <option value="t7">Mesa 7 (4 pers.)</option>
                      <option value="t8">Mesa 8 (2 pers.)</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Notas (opcional)
                  </label>
                  <textarea className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Preferencias o solicitudes especiales" rows={2}></textarea>
                </div>
              </div>
            </div>
            <div className="p-4 border-t border-gray-200 flex justify-end space-x-2">
              <button className={softBtn('gray')} onClick={() => setShowReservationModal(false)}>
                Cancelar
              </button>
              <button className={ctaGrad()} onClick={() => {
            const newReservation: Reservation = {
              id: `r${reservations.length + 1}`,
              name: 'Nuevo Cliente',
              phone: '3001234567',
              identification: '1234567890',
              date: new Date().toISOString().split('T')[0],
              time: '20:00',
              guests: 2,
              tableId: '',
              tableNumber: 0,
              status: 'pending'
            };
            setReservations([...reservations, newReservation]);
            showToast('success', 'Reservación creada correctamente');
            setShowReservationModal(false);
          }}>
                <CheckIcon size={16} className="mr-1" />
                Guardar reservación
              </button>
            </div>
          </div>
        </div>}
    </div>;
};
export default ReservationsPage;