import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../contexts/ToastContext';
import { useAuth } from '../../contexts/AuthContext';
import { UserPlusIcon, SaveIcon, UserIcon, BuildingIcon, PhoneIcon, MailIcon, IdCardIcon, MapPinIcon, EyeIcon, EyeOffIcon, CheckCircleIcon, XCircleIcon, SearchIcon } from 'lucide-react';
const ConfigurationPage = () => {
  const {
    showToast
  } = useToast();
  const navigate = useNavigate();
  const {
    user
  } = useAuth();
  const [activeTab, setActiveTab] = useState('business');
  const [loading, setLoading] = useState(false);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);
  // Business settings form state
  const [businessSettings, setBusinessSettings] = useState({
    name: 'Mi Restaurante',
    nit: '901.234.567-8',
    address: 'Calle 123 #45-67, Ciudad',
    phone: '(601) 123-4567',
    email: 'contacto@mirestaurante.com',
    website: 'www.mirestaurante.com',
    taxRate: 19,
    currencySymbol: '$',
    logoUrl: ''
  });
  // New user form state
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'waiter'
  });
  // Password change form state
  const [passwordChange, setPasswordChange] = useState({
    userId: '',
    password: '',
    confirmPassword: ''
  });
  // Mock users data (in a real app, this would come from a database)
  const [users, setUsers] = useState([{
    id: 1,
    name: 'Admin User',
    email: 'admin@example.com',
    role: 'admin',
    active: true,
    lastLogin: '2023-04-15T10:30:00Z'
  }, {
    id: 2,
    name: 'Carlos Rodríguez',
    email: 'carlos@example.com',
    role: 'waiter',
    active: true,
    lastLogin: '2023-04-14T15:45:00Z'
  }, {
    id: 3,
    name: 'María López',
    email: 'maria@example.com',
    role: 'waiter',
    active: true,
    lastLogin: '2023-04-14T09:20:00Z'
  }, {
    id: 4,
    name: 'Juan Pérez',
    email: 'juan@example.com',
    role: 'cook',
    active: true,
    lastLogin: '2023-04-13T18:10:00Z'
  }, {
    id: 5,
    name: 'Ana García',
    email: 'ana@example.com',
    role: 'cashier',
    active: false,
    lastLogin: '2023-04-10T12:05:00Z'
  }]);
  // Check if user has admin permissions
  useEffect(() => {
    if (user?.role !== 'admin') {
      showToast('error', 'No tienes permisos para acceder a esta página');
      navigate('/dashboard');
    }
  }, [user, navigate, showToast]);
  // Handle business settings form submission
  const handleBusinessSettingsSubmit = e => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      showToast('success', 'Configuración del negocio actualizada correctamente');
    }, 1000);
  };
  // Handle adding a new user
  const handleAddUser = e => {
    e.preventDefault();
    if (newUser.password !== newUser.confirmPassword) {
      showToast('error', 'Las contraseñas no coinciden');
      return;
    }
    setLoading(true);
    // Simulate API call to create user
    setTimeout(() => {
      const newUserId = users.length + 1;
      setUsers([...users, {
        id: newUserId,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        active: true,
        lastLogin: null
      }]);
      setLoading(false);
      setShowAddUserModal(false);
      setNewUser({
        name: '',
        email: '',
        password: '',
        confirmPassword: '',
        role: 'waiter'
      });
      showToast('success', 'Usuario creado correctamente');
    }, 1000);
  };
  // Handle toggling user active status
  const toggleUserStatus = userId => {
    setUsers(users.map(user => user.id === userId ? {
      ...user,
      active: !user.active
    } : user));
    const targetUser = users.find(user => user.id === userId);
    showToast('success', `Usuario ${targetUser.name} ${targetUser.active ? 'desactivado' : 'activado'} correctamente`);
  };
  // Handle changing user password
  const handleChangePassword = e => {
    e.preventDefault();
    if (passwordChange.password !== passwordChange.confirmPassword) {
      showToast('error', 'Las contraseñas no coinciden');
      return;
    }
    setLoading(true);
    // Simulate API call to change password
    setTimeout(() => {
      setLoading(false);
      setShowPasswordModal(false);
      setPasswordChange({
        userId: '',
        password: '',
        confirmPassword: ''
      });
      showToast('success', 'Contraseña actualizada correctamente');
    }, 1000);
  };
  // Filter users based on search term
  const filteredUsers = users.filter(user => user.name.toLowerCase().includes(searchTerm.toLowerCase()) || user.email.toLowerCase().includes(searchTerm.toLowerCase()));
  // Format date for display
  const formatDate = dateString => {
    if (!dateString) return 'Nunca';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('es-CO', {
      dateStyle: 'medium',
      timeStyle: 'short'
    }).format(date);
  };
  // Get role name in Spanish
  const getRoleName = role => {
    switch (role) {
      case 'admin':
        return 'Administrador';
      case 'waiter':
        return 'Mesero';
      case 'cook':
        return 'Cocinero';
      case 'cashier':
        return 'Cajero';
      default:
        return role;
    }
  };
  return <div className="max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Configuración del Sistema</h1>
      {/* Tabs */}
      <div className="flex border-b border-gray-200 mb-6">
        <button className={`px-4 py-2 font-medium text-sm ${activeTab === 'business' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('business')}>
          Información del Negocio
        </button>
        <button className={`px-4 py-2 font-medium text-sm ${activeTab === 'users' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('users')}>
          Gestión de Usuarios
        </button>
      </div>
      {/* Business Settings Tab */}
      {activeTab === 'business' && <div>
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium mb-4">
              Información del Negocio
            </h2>
            <p className="text-sm text-gray-500 mb-6">
              Esta información se utilizará en los tickets, facturas y reportes.
            </p>
            <form onSubmit={handleBusinessSettingsSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nombre del Negocio
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <BuildingIcon size={16} className="text-gray-400" />
                    </div>
                    <input type="text" value={businessSettings.name} onChange={e => setBusinessSettings({
                  ...businessSettings,
                  name: e.target.value
                })} className="pl-10 block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    NIT / Identificación Fiscal
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <IdCardIcon size={16} className="text-gray-400" />
                    </div>
                    <input type="text" value={businessSettings.nit} onChange={e => setBusinessSettings({
                  ...businessSettings,
                  nit: e.target.value
                })} className="pl-10 block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Dirección
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <MapPinIcon size={16} className="text-gray-400" />
                    </div>
                    <input type="text" value={businessSettings.address} onChange={e => setBusinessSettings({
                  ...businessSettings,
                  address: e.target.value
                })} className="pl-10 block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Teléfono
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <PhoneIcon size={16} className="text-gray-400" />
                    </div>
                    <input type="text" value={businessSettings.phone} onChange={e => setBusinessSettings({
                  ...businessSettings,
                  phone: e.target.value
                })} className="pl-10 block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Correo Electrónico
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <MailIcon size={16} className="text-gray-400" />
                    </div>
                    <input type="email" value={businessSettings.email} onChange={e => setBusinessSettings({
                  ...businessSettings,
                  email: e.target.value
                })} className="pl-10 block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tasa de Impuesto (%)
                  </label>
                  <input type="number" value={businessSettings.taxRate} onChange={e => setBusinessSettings({
                ...businessSettings,
                taxRate: parseInt(e.target.value)
              })} min="0" max="100" className="block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required />
                </div>
              </div>
              <div className="mt-6 flex justify-end">
                <button type="submit" className="flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" disabled={loading}>
                  {loading ? <span className="inline-block h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin mr-2"></span> : <SaveIcon size={16} className="mr-2" />}
                  Guardar Cambios
                </button>
              </div>
            </form>
          </div>
        </div>}
      {/* Users Tab */}
      {activeTab === 'users' && <div>
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-lg font-medium">Gestión de Usuarios</h2>
                <button onClick={() => setShowAddUserModal(true)} className="flex items-center px-3 py-1.5 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                  <UserPlusIcon size={16} className="mr-1" />
                  Nuevo Usuario
                </button>
              </div>
              <div className="mb-4 relative">
                <input type="text" placeholder="Buscar usuarios..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="pl-10 block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <SearchIcon size={16} className="text-gray-400" />
                </div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Usuario
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Rol
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Estado
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Último Acceso
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Acciones
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredUsers.map(user => <tr key={user.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 bg-gray-100 rounded-full flex items-center justify-center">
                            <UserIcon size={16} className="text-gray-500" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                              {user.name}
                            </div>
                            <div className="text-sm text-gray-500">
                              {user.email}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                          {getRoleName(user.role)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className={`flex-shrink-0 h-2.5 w-2.5 rounded-full mr-2 ${user.active ? 'bg-green-500' : 'bg-red-500'}`}></div>
                          <span className={`text-sm ${user.active ? 'text-green-800' : 'text-red-800'}`}>
                            {user.active ? 'Activo' : 'Inactivo'}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(user.lastLogin)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end space-x-2">
                          <button onClick={() => {
                      setSelectedUser(user);
                      setPasswordChange({
                        ...passwordChange,
                        userId: user.id
                      });
                      setShowPasswordModal(true);
                    }} className="text-blue-600 hover:text-blue-900" title="Cambiar contraseña">
                            <EyeIcon size={16} />
                          </button>
                          {user.role !== 'admin' && <button onClick={() => toggleUserStatus(user.id)} className={`${user.active ? 'text-red-600 hover:text-red-900' : 'text-green-600 hover:text-green-900'}`} title={user.active ? 'Desactivar usuario' : 'Activar usuario'}>
                              {user.active ? <XCircleIcon size={16} /> : <CheckCircleIcon size={16} />}
                            </button>}
                        </div>
                      </td>
                    </tr>)}
                </tbody>
              </table>
            </div>
            {filteredUsers.length === 0 && <div className="text-center py-4 text-gray-500">
                No se encontraron usuarios
              </div>}
          </div>
        </div>}
      {/* Add User Modal */}
      {showAddUserModal && <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 flex items-center justify-center">
          <div className="relative mx-auto p-5 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Agregar Nuevo Usuario</h3>
              <button onClick={() => setShowAddUserModal(false)} className="text-gray-400 hover:text-gray-600">
                <XCircleIcon size={20} />
              </button>
            </div>
            <form onSubmit={handleAddUser}>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nombre Completo
                </label>
                <input type="text" value={newUser.name} onChange={e => setNewUser({
              ...newUser,
              name: e.target.value
            })} className="block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Correo Electrónico
                </label>
                <input type="email" value={newUser.email} onChange={e => setNewUser({
              ...newUser,
              email: e.target.value
            })} className="block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Contraseña
                </label>
                <div className="relative">
                  <input type="password" value={newUser.password} onChange={e => setNewUser({
                ...newUser,
                password: e.target.value
              })} className="block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required minLength={6} />
                </div>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Confirmar Contraseña
                </label>
                <input type="password" value={newUser.confirmPassword} onChange={e => setNewUser({
              ...newUser,
              confirmPassword: e.target.value
            })} className="block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required minLength={6} />
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Rol
                </label>
                <select value={newUser.role} onChange={e => setNewUser({
              ...newUser,
              role: e.target.value
            })} className="block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required>
                  <option value="waiter">Mesero</option>
                  <option value="cook">Cocinero</option>
                  <option value="cashier">Cajero</option>
                </select>
              </div>
              <div className="flex justify-end">
                <button type="button" onClick={() => setShowAddUserModal(false)} className="mr-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                  Cancelar
                </button>
                <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" disabled={loading}>
                  {loading ? <span className="inline-block h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin mr-1"></span> : null}
                  Crear Usuario
                </button>
              </div>
            </form>
          </div>
        </div>}
      {/* Change Password Modal */}
      {showPasswordModal && selectedUser && <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 flex items-center justify-center">
          <div className="relative mx-auto p-5 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">
                Cambiar Contraseña: {selectedUser.name}
              </h3>
              <button onClick={() => setShowPasswordModal(false)} className="text-gray-400 hover:text-gray-600">
                <XCircleIcon size={20} />
              </button>
            </div>
            <form onSubmit={handleChangePassword}>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nueva Contraseña
                </label>
                <div className="relative">
                  <input type="password" value={passwordChange.password} onChange={e => setPasswordChange({
                ...passwordChange,
                password: e.target.value
              })} className="block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required minLength={6} />
                </div>
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Confirmar Nueva Contraseña
                </label>
                <input type="password" value={passwordChange.confirmPassword} onChange={e => setPasswordChange({
              ...passwordChange,
              confirmPassword: e.target.value
            })} className="block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required minLength={6} />
              </div>
              <div className="flex justify-end">
                <button type="button" onClick={() => setShowPasswordModal(false)} className="mr-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                  Cancelar
                </button>
                <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" disabled={loading}>
                  {loading ? <span className="inline-block h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin mr-1"></span> : null}
                  Actualizar Contraseña
                </button>
              </div>
            </form>
          </div>
        </div>}
    </div>;
};
export default ConfigurationPage;