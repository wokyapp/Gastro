import React, { useEffect, useState } from 'react';
import { useToast } from '../contexts/ToastContext';
import { BuildingIcon, ReceiptIcon, FileTextIcon, CreditCardIcon, UsersIcon, DatabaseIcon, SaveIcon, PlusIcon } from 'lucide-react';
import Modal from '../components/ui/Modal';
import Skeleton from '../components/ui/Skeleton';
import { mockBusinessSettings } from '../utils/mockData';
const SettingsPage: React.FC = () => {
  const {
    showToast
  } = useToast();
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'business' | 'ticket' | 'billing' | 'payments' | 'users' | 'exports'>('business');
  const [showResetPinModal, setShowResetPinModal] = useState(false);
  // Cargar configuración
  useEffect(() => {
    const loadSettings = async () => {
      await new Promise(resolve => setTimeout(resolve, 800));
      setSettings(mockBusinessSettings);
      setLoading(false);
    };
    loadSettings();
  }, []);
  // Guardar configuración
  const handleSaveSettings = (section: string, data: any) => {
    setLoading(true);
    // Simular petición a API
    setTimeout(() => {
      setSettings({
        ...settings,
        ...data
      });
      setLoading(false);
      showToast('success', 'Configuración guardada correctamente');
    }, 1000);
  };
  // Restablecer PIN de supervisor
  const handleResetSupervisorPin = (newPin: string) => {
    setLoading(true);
    // Simular petición a API
    setTimeout(() => {
      setLoading(false);
      setShowResetPinModal(false);
      showToast('success', 'PIN de supervisor restablecido correctamente');
    }, 1500);
  };
  // Renderizar contenido según la pestaña activa
  const renderTabContent = () => {
    if (loading) {
      return <div className="space-y-4 p-4">
          <Skeleton height={50} className="rounded-xl" />
          <Skeleton height={50} className="rounded-xl" />
          <Skeleton height={50} className="rounded-xl" />
          <Skeleton height={50} className="rounded-xl" />
        </div>;
    }
    switch (activeTab) {
      case 'business':
        return <BusinessSettings settings={settings} onSave={handleSaveSettings} />;
      case 'ticket':
        return <TicketSettings settings={settings} onSave={handleSaveSettings} />;
      case 'billing':
        return <BillingSettings settings={settings} onSave={handleSaveSettings} />;
      case 'payments':
        return <PaymentSettings settings={settings} onSave={handleSaveSettings} />;
      case 'users':
        return <UserSettings onResetPin={() => setShowResetPinModal(true)} />;
      case 'exports':
        return <ExportSettings />;
      default:
        return null;
    }
  };
  return <div className="h-full">
      <h1 className="text-2xl font-bold text-gray-800 mb-4">Ajustes</h1>
      <div className="bg-white rounded-2xl shadow overflow-hidden">
        <div className="flex overflow-x-auto">
          <button className={`py-3 px-4 text-center whitespace-nowrap font-medium ${activeTab === 'business' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('business')}>
            <BuildingIcon size={16} className="inline-block mr-1" />
            Comercio
          </button>
          <button className={`py-3 px-4 text-center whitespace-nowrap font-medium ${activeTab === 'ticket' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('ticket')}>
            <ReceiptIcon size={16} className="inline-block mr-1" />
            Ticket
          </button>
          <button className={`py-3 px-4 text-center whitespace-nowrap font-medium ${activeTab === 'billing' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('billing')}>
            <FileTextIcon size={16} className="inline-block mr-1" />
            Facturación
          </button>
          <button className={`py-3 px-4 text-center whitespace-nowrap font-medium ${activeTab === 'payments' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('payments')}>
            <CreditCardIcon size={16} className="inline-block mr-1" />
            Pagos
          </button>
          <button className={`py-3 px-4 text-center whitespace-nowrap font-medium ${activeTab === 'users' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('users')}>
            <UsersIcon size={16} className="inline-block mr-1" />
            Usuarios
          </button>
          <button className={`py-3 px-4 text-center whitespace-nowrap font-medium ${activeTab === 'exports' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('exports')}>
            <DatabaseIcon size={16} className="inline-block mr-1" />
            Exportaciones
          </button>
        </div>
        <div className="border-t border-gray-200">{renderTabContent()}</div>
      </div>
      {/* Modal para restablecer PIN de supervisor */}
      <ResetPinModal isOpen={showResetPinModal} onClose={() => setShowResetPinModal(false)} onSubmit={handleResetSupervisorPin} />
    </div>;
};
// Configuración del comercio
const BusinessSettings: React.FC<{
  settings: any;
  onSave: (section: string, data: any) => void;
}> = ({
  settings,
  onSave
}) => {
  const [name, setName] = useState(settings.name);
  const [nit, setNit] = useState(settings.nit);
  const [address, setAddress] = useState(settings.address);
  const [phone, setPhone] = useState(settings.phone);
  const [email, setEmail] = useState(settings.email);
  const [logo, setLogo] = useState<string | null>(settings.logo);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave('business', {
      name,
      nit,
      address,
      phone,
      email,
      logo
    });
  };
  // Simulación de carga de logo
  const handleLogoUpload = () => {
    // En una implementación real, aquí se cargaría el archivo
    // Para la demostración, simplemente asignamos una URL de ejemplo
    setLogo('https://via.placeholder.com/150x50?text=Logo+Empresa');
  };
  return <form onSubmit={handleSubmit} className="p-4 space-y-4">
      <div>
        <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
          Nombre del comercio
        </label>
        <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
      </div>
      <div>
        <label htmlFor="nit" className="block text-sm font-medium text-gray-700 mb-1">
          NIT
        </label>
        <input type="text" id="nit" value={nit} onChange={e => setNit(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
      </div>
      <div>
        <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
          Dirección
        </label>
        <input type="text" id="address" value={address} onChange={e => setAddress(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
            Teléfono
          </label>
          <input type="text" id="phone" value={phone} onChange={e => setPhone(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
        </div>
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
            Correo electrónico
          </label>
          <input type="email" id="email" value={email} onChange={e => setEmail(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
        </div>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Logo (opcional)
        </label>
        {logo ? <div className="mb-3">
            <img src={logo} alt="Logo de la empresa" className="h-12 border border-gray-200 rounded-md p-1" />
            <button type="button" onClick={() => setLogo(null)} className="text-red-600 text-sm mt-1">
              Eliminar logo
            </button>
          </div> : <div onClick={handleLogoUpload} className="flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-4 cursor-pointer hover:bg-gray-50">
            <div className="space-y-1 text-center">
              <svg className="mx-auto h-10 w-10 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <p className="text-xs text-gray-500">Subir imagen (PNG, JPG)</p>
              <p className="text-xs text-gray-400">
                Tamaño recomendado: 150x50px
              </p>
            </div>
          </div>}
      </div>
      <div className="pt-4 flex justify-end">
        <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg flex items-center">
          <SaveIcon size={16} className="mr-1" />
          Guardar cambios
        </button>
      </div>
    </form>;
};
// Configuración del ticket
const TicketSettings: React.FC<{
  settings: any;
  onSave: (section: string, data: any) => void;
}> = ({
  settings,
  onSave
}) => {
  const [defaultChannel, setDefaultChannel] = useState(settings.ticketSettings.defaultChannel);
  const [showLogo, setShowLogo] = useState(settings.ticketSettings.showLogo);
  const [legalNotes, setLegalNotes] = useState(settings.ticketSettings.legalNotes);
  const [includeQR, setIncludeQR] = useState(settings.ticketSettings.includeQR);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave('ticketSettings', {
      ticketSettings: {
        defaultChannel,
        showLogo,
        legalNotes,
        includeQR
      }
    });
  };
  return <form onSubmit={handleSubmit} className="p-4 space-y-4">
      <div>
        <label htmlFor="defaultChannel" className="block text-sm font-medium text-gray-700 mb-1">
          Canal de envío por defecto
        </label>
        <select id="defaultChannel" value={defaultChannel} onChange={e => setDefaultChannel(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
          <option value="whatsapp">WhatsApp</option>
          <option value="email">Email</option>
          <option value="qr">Código QR</option>
          <option value="print">Imprimir</option>
        </select>
      </div>
      <div className="flex items-center">
        <input type="checkbox" id="showLogo" checked={showLogo} onChange={e => setShowLogo(e.target.checked)} className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
        <label htmlFor="showLogo" className="ml-2 block text-sm text-gray-700">
          Mostrar logo en el ticket
        </label>
      </div>
      <div className="flex items-center">
        <input type="checkbox" id="includeQR" checked={includeQR} onChange={e => setIncludeQR(e.target.checked)} className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
        <label htmlFor="includeQR" className="ml-2 block text-sm text-gray-700">
          Incluir código QR para verificación
        </label>
      </div>
      <div>
        <label htmlFor="legalNotes" className="block text-sm font-medium text-gray-700 mb-1">
          Notas legales
        </label>
        <textarea id="legalNotes" value={legalNotes} onChange={e => setLegalNotes(e.target.value)} rows={3} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
        <p className="mt-1 text-xs text-gray-500">
          Este texto aparecerá en la parte inferior de todos los tickets.
        </p>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Logo (opcional)
        </label>
        <div className="flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-4 cursor-pointer hover:bg-gray-50">
          <div className="space-y-1 text-center">
            <svg className="mx-auto h-10 w-10 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
              <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <p className="text-xs text-gray-500">Subir imagen (PNG, JPG)</p>
          </div>
        </div>
      </div>
      <div className="pt-4 flex justify-end">
        <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg flex items-center">
          <SaveIcon size={16} className="mr-1" />
          Guardar cambios
        </button>
      </div>
    </form>;
};
// Configuración de facturación
const BillingSettings: React.FC<{
  settings: any;
  onSave: (section: string, data: any) => void;
}> = ({
  settings,
  onSave
}) => {
  const [enableOnDemand, setEnableOnDemand] = useState(settings.billingSettings.enableOnDemand);
  const [prefix, setPrefix] = useState(settings.billingSettings.prefix);
  const [resolution, setResolution] = useState(settings.billingSettings.resolution);
  const [validUntil, setValidUntil] = useState(settings.billingSettings.validUntil);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave('billingSettings', {
      billingSettings: {
        enableOnDemand,
        prefix,
        resolution,
        validUntil
      }
    });
  };
  return <form onSubmit={handleSubmit} className="p-4 space-y-4">
      <div className="flex items-center">
        <input type="checkbox" id="enableOnDemand" checked={enableOnDemand} onChange={e => setEnableOnDemand(e.target.checked)} className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
        <label htmlFor="enableOnDemand" className="ml-2 block text-sm text-gray-700">
          Habilitar facturación bajo demanda
        </label>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="prefix" className="block text-sm font-medium text-gray-700 mb-1">
            Prefijo
          </label>
          <input type="text" id="prefix" value={prefix} onChange={e => setPrefix(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
        </div>
        <div>
          <label htmlFor="resolution" className="block text-sm font-medium text-gray-700 mb-1">
            Resolución DIAN
          </label>
          <input type="text" id="resolution" value={resolution} onChange={e => setResolution(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
        </div>
      </div>
      <div>
        <label htmlFor="validUntil" className="block text-sm font-medium text-gray-700 mb-1">
          Válida hasta
        </label>
        <input type="date" id="validUntil" value={validUntil} onChange={e => setValidUntil(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
      </div>
      <div className="pt-4 flex justify-end">
        <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg flex items-center">
          <SaveIcon size={16} className="mr-1" />
          Guardar cambios
        </button>
      </div>
    </form>;
};
// Configuración de pagos
const PaymentSettings: React.FC<{
  settings: any;
  onSave: (section: string, data: any) => void;
}> = ({
  settings,
  onSave
}) => {
  const [defaultRail, setDefaultRail] = useState(settings.paymentSettings.defaultRail);
  const [refundLimit, setRefundLimit] = useState(settings.paymentSettings.refundLimit);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave('paymentSettings', {
      paymentSettings: {
        ...settings.paymentSettings,
        defaultRail,
        refundLimit: Number(refundLimit)
      }
    });
  };
  return <form onSubmit={handleSubmit} className="p-4 space-y-4">
      <div>
        <label htmlFor="defaultRail" className="block text-sm font-medium text-gray-700 mb-1">
          Pasarela de pago predeterminada
        </label>
        <select id="defaultRail" value={defaultRail} onChange={e => setDefaultRail(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
          <option value="transfiya">TransfiyaMock</option>
          <option value="breb">BreBMock</option>
          <option value="ach">ACHFallback</option>
        </select>
        <p className="mt-1 text-xs text-gray-500">
          Esta es la pasarela que se usará por defecto para procesar pagos con
          tarjeta.
        </p>
      </div>
      <div>
        <label htmlFor="refundLimit" className="block text-sm font-medium text-gray-700 mb-1">
          Límite de reembolso sin autorización
        </label>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <span className="text-gray-500">$</span>
          </div>
          <input type="number" id="refundLimit" value={refundLimit} onChange={e => setRefundLimit(e.target.value)} className="pl-7 block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
        </div>
        <p className="mt-1 text-xs text-gray-500">
          Reembolsos por encima de este monto requerirán PIN de supervisor.
        </p>
      </div>
      <div className="pt-4 flex justify-end">
        <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg flex items-center">
          <SaveIcon size={16} className="mr-1" />
          Guardar cambios
        </button>
      </div>
    </form>;
};
// Configuración de usuarios
const UserSettings: React.FC<{
  onResetPin: () => void;
}> = ({
  onResetPin
}) => {
  const {
    showToast
  } = useToast();
  const [users, setUsers] = useState([{
    id: '1',
    name: 'Cajero Demo',
    email: 'cajero@demo',
    role: 'cajero',
    active: true
  }, {
    id: '2',
    name: 'Supervisor Demo',
    email: 'supervisor@demo',
    role: 'supervisor',
    active: true
  }, {
    id: '3',
    name: 'Administrador Demo',
    email: 'admin@demo',
    role: 'admin',
    active: true
  }]);
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [userRole, setUserRole] = useState('cajero');
  const [userActive, setUserActive] = useState(true);
  // Abrir modal para crear/editar usuario
  const openUserModal = (user: any = null) => {
    if (user) {
      setEditingUser(user);
      setUserName(user.name);
      setUserEmail(user.email);
      setUserRole(user.role);
      setUserActive(user.active);
    } else {
      setEditingUser(null);
      setUserName('');
      setUserEmail('');
      setUserRole('cajero');
      setUserActive(true);
    }
    setShowUserModal(true);
  };
  // Guardar usuario
  const handleSaveUser = () => {
    if (!userName || !userEmail) {
      showToast('error', 'Por favor complete todos los campos obligatorios');
      return;
    }
    if (editingUser) {
      // Actualizar usuario existente
      const updatedUsers = users.map(user => {
        if (user.id === editingUser.id) {
          return {
            ...user,
            name: userName,
            email: userEmail,
            role: userRole,
            active: userActive
          };
        }
        return user;
      });
      setUsers(updatedUsers);
      showToast('success', 'Usuario actualizado correctamente');
    } else {
      // Crear nuevo usuario
      const newUser = {
        id: `${users.length + 1}`,
        name: userName,
        email: userEmail,
        role: userRole,
        active: userActive
      };
      setUsers([...users, newUser]);
      showToast('success', 'Usuario creado correctamente');
    }
    setShowUserModal(false);
  };
  // Cambiar estado activo/inactivo del usuario
  const toggleUserActive = (userId: string) => {
    const updatedUsers = users.map(user => {
      if (user.id === userId) {
        const newStatus = !user.active;
        // Mostrar mensaje de confirmación
        showToast('success', `Usuario ${newStatus ? 'activado' : 'desactivado'} correctamente`);
        return {
          ...user,
          active: newStatus
        };
      }
      return user;
    });
    setUsers(updatedUsers);
  };
  return <div className="p-4 space-y-4">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-medium text-gray-800">Usuarios del sistema</h3>
        <button onClick={() => openUserModal()} className="bg-blue-600 hover:bg-blue-700 text-white py-1.5 px-3 rounded-lg text-sm flex items-center">
          <PlusIcon size={16} className="mr-1" />
          Nuevo usuario
        </button>
      </div>
      <div className="overflow-x-auto -mx-4 px-4">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Usuario
              </th>
              <th className="py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Correo
              </th>
              <th className="py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Rol
              </th>
              <th className="py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Estado
              </th>
              <th className="py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Acciones
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {users.map(user => <tr key={user.id} className="hover:bg-gray-50">
                <td className="py-3 text-sm font-medium text-gray-800">
                  {user.name}
                </td>
                <td className="py-3 text-sm text-gray-800">{user.email}</td>
                <td className="py-3 text-sm">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${user.role === 'admin' ? 'bg-purple-100 text-purple-800' : user.role === 'supervisor' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}`}>
                    {user.role === 'admin' ? 'Administrador' : user.role === 'supervisor' ? 'Supervisor' : 'Cajero'}
                  </span>
                </td>
                <td className="py-3 text-sm">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${user.active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {user.active ? 'Activo' : 'Inactivo'}
                  </span>
                </td>
                <td className="py-3 text-sm text-right">
                  <button onClick={() => openUserModal(user)} className="text-blue-600 hover:text-blue-900 mr-3">
                    Editar
                  </button>
                  {user.role === 'supervisor' && <button onClick={onResetPin} className="text-blue-600 hover:text-blue-900">
                      Restablecer PIN
                    </button>}
                </td>
              </tr>)}
          </tbody>
        </table>
      </div>
      {/* Modal para crear/editar usuario */}
      <Modal isOpen={showUserModal} onClose={() => setShowUserModal(false)} title={editingUser ? 'Editar usuario' : 'Nuevo usuario'} footer={<div className="flex justify-end space-x-2">
            <button type="button" onClick={() => setShowUserModal(false)} className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
              Cancelar
            </button>
            <button type="button" onClick={handleSaveUser} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              {editingUser ? 'Guardar cambios' : 'Crear usuario'}
            </button>
          </div>}>
        <div className="space-y-4">
          <div>
            <label htmlFor="userName" className="block text-sm font-medium text-gray-700 mb-1">
              Nombre <span className="text-red-500">*</span>
            </label>
            <input type="text" id="userName" value={userName} onChange={e => setUserName(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
          </div>
          <div>
            <label htmlFor="userEmail" className="block text-sm font-medium text-gray-700 mb-1">
              Correo electrónico <span className="text-red-500">*</span>
            </label>
            <input type="email" id="userEmail" value={userEmail} onChange={e => setUserEmail(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
          </div>
          <div>
            <label htmlFor="userRole" className="block text-sm font-medium text-gray-700 mb-1">
              Rol
            </label>
            <select id="userRole" value={userRole} onChange={e => setUserRole(e.target.value)} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
              <option value="cajero">Cajero</option>
              <option value="supervisor">Supervisor</option>
              <option value="admin">Administrador</option>
            </select>
          </div>
          <div className="flex items-center">
            <input type="checkbox" id="userActive" checked={userActive} onChange={e => setUserActive(e.target.checked)} className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" />
            <label htmlFor="userActive" className="ml-2 block text-sm text-gray-700">
              Usuario activo
            </label>
          </div>
          {editingUser && <div className="pt-2 border-t border-gray-200 mt-4">
              <p className="text-sm text-gray-500">
                Si es necesario restablecer la contraseña, use la opción
                "Restablecer PIN" desde la lista de usuarios.
              </p>
            </div>}
        </div>
      </Modal>
    </div>;
};
// Configuración de exportaciones
const ExportSettings: React.FC = () => {
  const {
    showToast
  } = useToast();
  const handleExport = (format: string) => {
    showToast('info', `Exportando en formato ${format}...`);
    // Simulación de exportación
    setTimeout(() => {
      showToast('success', `Datos exportados en formato ${format} correctamente`);
    }, 1500);
  };
  return <div className="p-4 space-y-4">
      <div className="bg-blue-50 rounded-lg p-3 mb-2">
        <p className="text-sm text-blue-800">
          Exporta tus datos para usar en otros sistemas contables o de gestión.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="border border-gray-200 rounded-lg p-4">
          <h3 className="font-medium text-gray-800 mb-2">Siigo</h3>
          <p className="text-sm text-gray-600 mb-4">
            Exporta tus ventas y productos en formato compatible con Siigo.
          </p>
          <button onClick={() => handleExport('Siigo')} className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg flex items-center">
            <DatabaseIcon size={16} className="mr-1" />
            Exportar para Siigo
          </button>
        </div>
        <div className="border border-gray-200 rounded-lg p-4">
          <h3 className="font-medium text-gray-800 mb-2">Alegra</h3>
          <p className="text-sm text-gray-600 mb-4">
            Exporta tus ventas y productos en formato compatible con Alegra.
          </p>
          <button onClick={() => handleExport('Alegra')} className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg flex items-center">
            <DatabaseIcon size={16} className="mr-1" />
            Exportar para Alegra
          </button>
        </div>
      </div>
    </div>;
};
// Modal para restablecer PIN de supervisor
const ResetPinModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (newPin: string) => void;
}> = ({
  isOpen,
  onClose,
  onSubmit
}) => {
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [adminPin, setAdminPin] = useState('');
  const [error, setError] = useState('');
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin !== confirmPin) {
      setError('Los PINs no coinciden');
      return;
    }
    if (adminPin !== '1234') {
      setError('PIN de administrador incorrecto');
      return;
    }
    onSubmit(newPin);
  };
  return <Modal isOpen={isOpen} onClose={onClose} title="Restablecer PIN de supervisor" footer={<div className="flex justify-end space-x-2">
          <button type="button" onClick={onClose} className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
            Cancelar
          </button>
          <button type="button" onClick={handleSubmit} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" disabled={!newPin || !confirmPin || !adminPin}>
            Restablecer
          </button>
        </div>}>
      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
          {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
              {error}
            </div>}
          <div>
            <label htmlFor="newPin" className="block text-sm font-medium text-gray-700 mb-1">
              Nuevo PIN
            </label>
            <input type="password" id="newPin" value={newPin} onChange={e => {
            setNewPin(e.target.value);
            setError('');
          }} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Ingrese nuevo PIN" required />
          </div>
          <div>
            <label htmlFor="confirmPin" className="block text-sm font-medium text-gray-700 mb-1">
              Confirmar PIN
            </label>
            <input type="password" id="confirmPin" value={confirmPin} onChange={e => {
            setConfirmPin(e.target.value);
            setError('');
          }} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Confirme nuevo PIN" required />
          </div>
          <div>
            <label htmlFor="adminPin" className="block text-sm font-medium text-gray-700 mb-1">
              PIN de administrador
            </label>
            <input type="password" id="adminPin" value={adminPin} onChange={e => {
            setAdminPin(e.target.value);
            setError('');
          }} className="block w-full rounded-lg border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Ingrese PIN de administrador" required />
            <p className="mt-1 text-xs text-gray-500">
              Se requiere autorización de administrador para esta acción.
            </p>
          </div>
        </div>
      </form>
    </Modal>;
};
export default SettingsPage;